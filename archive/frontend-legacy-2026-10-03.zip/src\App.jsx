import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { AuthProvider } from './contexts/AuthContext'
import { ThemeProvider } from './contexts/ThemeContext'
import AuthGuard from './components/layout/AuthGuard'
import AppLayout from './components/layout/AppLayout'
import LoginScreen from './screens/auth/LoginScreen'
import RegisterScreen from './screens/auth/RegisterScreen'
import Dashboard from './screens/Dashboard'
import MarketView from './screens/MarketView'
import CropHealthScreen from './screens/CropHealthScreen'
import InputIntelScreen from './screens/InputIntelScreen'
import FinancialScreen from './screens/FinancialScreen'
import AdvisoryScreen from './screens/AdvisoryScreen'
import ProfileScreen from './screens/ProfileScreen'
import AdminScreen from './screens/AdminScreen'
import DataSyncScreen from './screens/DataSyncScreen'
import RoleGuard from './components/layout/RoleGuard'
import './index.css'

export default function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <BrowserRouter>
          <Routes>
            {/* Public */}
            <Route path="/login"    element={<LoginScreen />} />
            <Route path="/register" element={<RegisterScreen />} />

            {/* Protected */}
            <Route
              path="/app"
              element={<AuthGuard><AppLayout /></AuthGuard>}
            >
              <Route index              element={<Navigate to="dashboard" replace />} />
              <Route path="dashboard"  element={<Dashboard />} />
              <Route path="market"     element={<MarketView />} />
              <Route path="crop-health" element={<CropHealthScreen />} />
              <Route path="inputs"     element={<InputIntelScreen />} />
              <Route path="financial"  element={<FinancialScreen />} />
              <Route path="advisory"   element={<AdvisoryScreen />} />
              <Route path="profile"    element={<ProfileScreen />} />
              <Route path="admin"      element={<RoleGuard role="admin" fallback={<Navigate to="/app/dashboard" replace />}><AdminScreen /></RoleGuard>} />
              <Route path="data-sync"  element={<RoleGuard role="admin" fallback={<Navigate to="/app/dashboard" replace />}><DataSyncScreen /></RoleGuard>} />
            </Route>

            {/* Catch-all */}
            <Route path="*" element={<Navigate to="/app" replace />} />
          </Routes>
        </BrowserRouter>
      </AuthProvider>
    </ThemeProvider>
  )
}
