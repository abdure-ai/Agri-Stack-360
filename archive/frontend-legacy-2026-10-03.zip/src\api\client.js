// api/client.js — NMIS Agri-Platform API client

const BASE         = 'http://localhost:8000/api'
const PREDICT_BASE = 'http://localhost:8001'
const SYNC_BASE    = 'http://localhost:8002/sync'

function getToken() {
  return sessionStorage.getItem('nmis_token')
}

function authHeaders() {
  const t = getToken()
  return t ? { Authorization: `Bearer ${t}` } : {}
}

async function apiFetch(path, params = {}) {
  const url = new URL(BASE + path)
  Object.entries(params).forEach(([k, v]) => {
    if (v !== null && v !== undefined && v !== '') url.searchParams.set(k, v)
  })
  const res = await fetch(url.toString(), { headers: authHeaders() })
  if (!res.ok) {
    const text = await res.text()
    throw new Error(`API ${res.status}: ${text}`)
  }
  return res.json()
}

async function apiPost(path, body = {}) {
  const res = await fetch(BASE + path, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', ...authHeaders() },
    body: JSON.stringify(body),
  })
  const data = await res.json().catch(() => ({}))
  if (!res.ok) throw new Error(data.detail || `API ${res.status}`)
  return data
}

async function apiPut(path, body = {}) {
  const res = await fetch(BASE + path, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json', ...authHeaders() },
    body: JSON.stringify(body),
  })
  const data = await res.json().catch(() => ({}))
  if (!res.ok) throw new Error(data.detail || `API ${res.status}`)
  return data
}

async function apiDelete(path) {
  const res = await fetch(BASE + path, {
    method: 'DELETE',
    headers: authHeaders(),
  })
  if (!res.ok) {
    const data = await res.json().catch(() => ({}))
    throw new Error(data.detail || `API ${res.status}`)
  }
  return true
}

// Data sync service (port 8002) — separate process, same JWT
async function syncRequest(method, path, body) {
  const res = await fetch(SYNC_BASE + path, {
    method,
    headers: { 'Content-Type': 'application/json', ...authHeaders() },
    body: body === undefined ? undefined : JSON.stringify(body),
  })
  const data = await res.json().catch(() => ({}))
  if (!res.ok) {
    const detail = Array.isArray(data.detail) ? data.detail.map(d => d.msg).join('; ') : data.detail
    const err = new Error(detail || `Sync API ${res.status}`)
    err.status = res.status
    throw err
  }
  return data
}

async function predictFetch(path, params = {}) {
  const url = new URL(PREDICT_BASE + path)
  Object.entries(params).forEach(([k, v]) => {
    if (v !== null && v !== undefined && v !== '') url.searchParams.set(k, v)
  })
  const res = await fetch(url.toString())
  if (!res.ok) {
    const data = await res.json().catch(() => ({}))
    throw new Error(data.detail || `Predict API ${res.status}`)
  }
  return res.json()
}

export const api = {
  // ── Market price data (existing) ──────────────────────────────────────────
  meta:      () => apiFetch('/meta'),
  varieties: (crop)    => apiFetch('/varieties', { crop }),
  markets:   (region)  => apiFetch('/markets', { region }),
  prices:    (filters) => apiFetch('/prices', filters),
  summary:   (filters) => apiFetch('/summary', filters),
  regional:  (filters) => apiFetch('/regional', filters),
  spread:    (filters) => apiFetch('/spread', filters),

  // ── Prediction API (port 8001) ─────────────────────────────────────────────
  forecastHealth: () => predictFetch('/health'),
  forecast: (crop, region, weeks_ahead) =>
    predictFetch('/predict', { crop, region, weeks_ahead }),

  // ── Chat ──────────────────────────────────────────────────────────────────
  chat: (message, history) =>
    fetch(BASE + '/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...authHeaders() },
      body: JSON.stringify({ message, history }),
    }).then(r => r.json()),

  // ── Auth ──────────────────────────────────────────────────────────────────
  register: (data) => apiPost('/auth/register', data),
  login:    (data) => apiPost('/auth/login', data),
  refresh:  (refresh_token) => apiPost('/auth/refresh', { refresh_token }),
  me:       () => apiFetch('/auth/me'),

  // ── Users / Farms ──────────────────────────────────────────────────────────
  getProfile:    () => apiFetch('/users/profile'),
  updateProfile: (data) => apiPut('/users/profile', data),
  getFarms:      () => apiFetch('/users/farms'),
  addFarm:       (data) => apiPost('/users/farms', data),
  updateFarm:    (id, data) => apiPut(`/users/farms/${id}`, data),
  deleteFarm:    (id) => apiDelete(`/users/farms/${id}`),

  // ── Crop Health ────────────────────────────────────────────────────────────
  diagnose:        (data) => apiPost('/crop-health/diagnose', data),
  getHealthReports:(farm_id) => apiFetch('/crop-health/reports', farm_id ? { farm_id } : {}),
  saveHealthReport:(data) => apiPost('/crop-health/reports', data),
  resolveReport:   (id) => apiPut(`/crop-health/reports/${id}/resolve`, {}),

  // ── Suppliers ─────────────────────────────────────────────────────────────
  getSuppliers:    (params = {}) => apiFetch('/suppliers', params),
  compareSuppliers:(data) => apiPost('/suppliers/compare', data),

  // ── Financial ─────────────────────────────────────────────────────────────
  creditProfile:   () => apiFetch('/financial/profile'),
  loanProducts:    () => apiFetch('/financial/loan-products'),

  // ── Admin ─────────────────────────────────────────────────────────────────
  adminStats:      () => apiFetch('/admin/stats'),
  adminUsers:      () => apiFetch('/admin/users'),
  setUserRole:     (id, role) => apiPut(`/admin/users/${id}/role`, { role }),
  setUserActive:   (id, is_active) => apiPut(`/admin/users/${id}/active`, { is_active }),

  // ── Data sync (port 8002, admin only) ─────────────────────────────────────
  syncStatus:   () => syncRequest('GET', '/status'),
  syncOverview: () => syncRequest('GET', '/overview'),
  syncRuns:     (limit = 20) => syncRequest('GET', `/runs?limit=${limit}`),
  syncRun:      (id) => syncRequest('GET', `/runs/${id}`),
  syncRunLog:   (id, tail = 200) => syncRequest('GET', `/runs/${id}/log?tail=${tail}`),
  syncStart:    (opts) => syncRequest('POST', '/runs', opts),
  syncResume:   (id) => syncRequest('POST', `/runs/${id}/resume`),
  syncStop:     () => syncRequest('POST', '/stop'),
  syncSchedule: () => syncRequest('GET', '/schedule'),
  saveSyncSchedule: (settings) => syncRequest('PUT', '/schedule', settings),
}
