// components/FilterSidebar.jsx
import { useState, useEffect } from 'react'
import { clampDate } from '../utils/formatters'

const PRICE_LEVELS = [
  { key: 'retail',    label: 'Retail' },
  { key: 'wholesale', label: 'Wholesale' },
  { key: 'producer',  label: 'Producer' },
]

export default function FilterSidebar({ meta, filters, onApply }) {
  const [local, setLocal] = useState(filters)

  // Sync when parent resets
  useEffect(() => { setLocal(filters) }, [filters])

  // Cascading: when crop changes, reset variety and clamp dates
  useEffect(() => {
    if (!local.crop || !meta) return
    const cropMeta = meta.crops.find(c => c.name === local.crop)
    if (!cropMeta) return
    setLocal(prev => ({
      ...prev,
      variety: '',
      start_date: clampDate(prev.start_date, cropMeta.min_date, cropMeta.max_date) || cropMeta.min_date,
      end_date:   clampDate(prev.end_date,   cropMeta.min_date, cropMeta.max_date) || cropMeta.max_date,
    }))
  }, [local.crop, meta])

  // Cascading: when region changes, reset market selection
  useEffect(() => {
    setLocal(prev => ({ ...prev, markets: [] }))
  }, [local.region])

  if (!meta) {
    return (
      <aside className="filter-panel">
        <div className="state-container" style={{ padding: 40 }}>
          <div className="spinner" />
          <div className="state-sub">Loading filters…</div>
        </div>
      </aside>
    )
  }

  const cropMeta = meta.crops.find(c => c.name === local.crop)
  const varieties = local.crop ? (meta.varieties[local.crop] || []) : []
  const markets   = local.region ? (meta.markets[local.region] || []) : []

  function set(key, val) {
    setLocal(prev => ({ ...prev, [key]: val }))
  }

  function toggleMarket(id) {
    const cur = local.markets || []
    if (cur.includes(id)) {
      setLocal(prev => ({ ...prev, markets: cur.filter(m => m !== id) }))
    } else if (cur.length < 5) {
      setLocal(prev => ({ ...prev, markets: [...cur, id] }))
    }
  }

  function handleReset() {
    const reset = {
      crop: 'Teff', variety: '', region: '', markets: [],
      price_level: 'retail',
      start_date: '2019-03-30', end_date: '2026-08-11',
    }
    setLocal(reset)
    onApply(reset)
  }

  const cov = meta.price_level_coverage
  const coveragePct = {
    retail:    Math.round(cov.retail * 100),
    wholesale: Math.round(cov.wholesale * 100),
    producer:  Math.round(cov.producer * 100),
  }

  const isDateOutsideCrop = cropMeta && (
    local.start_date < cropMeta.min_date || local.start_date > cropMeta.max_date
  )

  return (
    <aside className="filter-panel">
      {/* Commodity */}
      <div className="sidebar-section">
        <span className="sidebar-label">Commodity</span>
        <select
          className="form-select"
          value={local.crop}
          onChange={e => set('crop', e.target.value)}
        >
          <option value="">All crops</option>
          {meta.crops.map(c => (
            <option key={c.id} value={c.name}>{c.name}</option>
          ))}
        </select>
      </div>

      {/* Variety */}
      <div className="sidebar-section">
        <span className="sidebar-label">Variety</span>
        <select
          className="form-select"
          value={local.variety}
          onChange={e => set('variety', e.target.value)}
          disabled={!local.crop || varieties.length === 0}
        >
          <option value="">All varieties</option>
          {varieties.map(v => (
            <option key={v.id} value={v.name}>{v.name}</option>
          ))}
        </select>
      </div>

      {/* Price Level */}
      <div className="sidebar-section">
        <span className="sidebar-label">Price Level</span>
        <div className="price-level-toggle">
          {PRICE_LEVELS.map(({ key, label }) => (
            <button
              key={key}
              data-level={key}
              className={`price-level-btn${local.price_level === key ? ' active' : ''}`}
              onClick={() => set('price_level', key)}
            >
              {label}
              <span className="coverage-badge">{coveragePct[key]}%</span>
            </button>
          ))}
        </div>
      </div>

      {/* Region */}
      <div className="sidebar-section">
        <span className="sidebar-label">Region</span>
        <select
          className="form-select"
          value={local.region}
          onChange={e => set('region', e.target.value)}
        >
          <option value="">All regions</option>
          {meta.regions.map(r => (
            <option key={r} value={r}>{r}</option>
          ))}
        </select>
      </div>

      {/* Market multi-select */}
      {local.region && (
        <div className="sidebar-section">
          <span className="sidebar-label">
            Markets — {(local.markets || []).length}/5 selected
          </span>
          <div className="market-multiselect">
            <div className="market-multiselect-inner">
              {markets.map(m => {
                const sel = (local.markets || []).includes(m.id)
                const maxed = !sel && (local.markets || []).length >= 5
                return (
                  <div
                    key={m.id}
                    className={`market-option${sel ? ' selected' : ''}${maxed ? ' disabled' : ''}`}
                    onClick={() => !maxed && toggleMarket(m.id)}
                    style={maxed ? { opacity: 0.4, cursor: 'not-allowed' } : undefined}
                  >
                    <div className="market-checkbox">
                      {sel && (
                        <svg width="8" height="6" viewBox="0 0 8 6" fill="none">
                          <path d="M1 3l2 2 4-4" stroke="white" strokeWidth="1.5" strokeLinecap="round"/>
                        </svg>
                      )}
                    </div>
                    {m.name}
                  </div>
                )
              })}
            </div>
            <div className="market-select-hint">Select up to 5 markets for comparison</div>
          </div>
        </div>
      )}

      {/* Date range */}
      <div className="sidebar-section">
        <span className="sidebar-label">Date Range</span>
        {cropMeta && (
          <div className="date-availability-notice">
            <span>ⓘ</span>
            <span>
              <strong>{local.crop}</strong> data available from{' '}
              <strong>{cropMeta.min_date}</strong>
            </span>
          </div>
        )}
        <div className="date-range-row">
          <div>
            <div className="sidebar-label" style={{ marginBottom: 3 }}>From</div>
            <input
              type="date"
              className="date-input"
              value={local.start_date}
              min={cropMeta?.min_date}
              max={local.end_date || cropMeta?.max_date}
              onChange={e => set('start_date', e.target.value)}
            />
          </div>
          <div>
            <div className="sidebar-label" style={{ marginBottom: 3 }}>To</div>
            <input
              type="date"
              className="date-input"
              value={local.end_date}
              min={local.start_date || cropMeta?.min_date}
              max={cropMeta?.max_date}
              onChange={e => set('end_date', e.target.value)}
            />
          </div>
        </div>
        {isDateOutsideCrop && (
          <div className="date-availability-notice" style={{ marginTop: 8 }}>
            <span>⚠</span>
            <span>Selected range is outside available data for {local.crop}. Chart may be empty.</span>
          </div>
        )}
      </div>

      {/* Actions */}
      <div className="sidebar-actions">
        <button className="btn-apply" onClick={() => onApply(local)}>
          Apply Filters
        </button>
        <button className="btn-reset" onClick={handleReset}>
          Reset
        </button>
      </div>
    </aside>
  )
}
