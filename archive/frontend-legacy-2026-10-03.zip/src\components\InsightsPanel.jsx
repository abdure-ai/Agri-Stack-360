// components/InsightsPanel.jsx
// Professional analytics summary card — rendered below each chart view.

export default function InsightsPanel({ headline, bullets, title = 'Market Analysis' }) {
  if (!bullets?.length) return null
  return (
    <div className="insights-panel">
      <div className="insights-header">
        <span className="insights-icon">◆</span>
        <span className="insights-title">{title}</span>
      </div>
      {headline && <p className="insights-headline">{headline}</p>}
      <ul className="insights-bullets">
        {bullets.map((b, i) => (
          <li key={i} className="insights-bullet">{b}</li>
        ))}
      </ul>
    </div>
  )
}
