// components/SummaryCards.jsx
import { formatETB, formatPct, formatFullDate } from '../utils/formatters'
import { PRICE_LEVEL_COLORS } from '../utils/colors'

function Skeleton() {
  return <div className="card-skeleton" />
}

function SupplyBadge({ signal }) {
  if (!signal) return <span className="supply-badge unknown">— No data</span>
  const cls = signal.toLowerCase() === 'sufficient' ? 'sufficient' : 'under'
  const icon = cls === 'sufficient' ? '●' : '▲'
  return (
    <span className={`supply-badge ${cls}`}>
      {icon} {signal}
    </span>
  )
}

export default function SummaryCards({ summary, filters, loading }) {
  const unit = summary?.unit || ''
  const level = filters?.price_level || 'retail'
  const accentColor = PRICE_LEVEL_COLORS[level] || PRICE_LEVEL_COLORS.retail

  const wow = summary ? formatPct(summary.wow_change_pct) : null

  return (
    <div className="summary-cards">
      {/* Latest Price */}
      <div className="summary-card" style={{ '--card-accent': accentColor }}>
        <div className="card-label">Latest Price</div>
        {loading ? <Skeleton /> : (
          <>
            <div className="card-value">
              {summary?.latest_price
                ? new Intl.NumberFormat('en-US').format(Math.round(summary.latest_price))
                : '—'}
            </div>
            <div className="card-sub">
              ETB/{unit || 'unit'}
              {summary?.latest_date && ` · ${formatFullDate(summary.latest_date)}`}
            </div>
          </>
        )}
      </div>

      {/* Week-over-Week */}
      <div className="summary-card" style={{ '--card-accent': wow?.cls === 'positive' ? 'var(--negative)' : wow?.cls === 'negative' ? 'var(--positive)' : 'var(--neutral)' }}>
        <div className="card-label">Week-over-Week</div>
        {loading ? <Skeleton /> : (
          <>
            <div className={`card-value ${wow?.cls || ''}`}>{wow?.text || '—'}</div>
            <div className="card-sub">vs. prior collection week</div>
          </>
        )}
      </div>

      {/* 4-Week Average */}
      <div className="summary-card" style={{ '--card-accent': 'var(--accent)' }}>
        <div className="card-label">4-Week Average</div>
        {loading ? <Skeleton /> : (
          <>
            <div className="card-value">
              {summary?.avg_4week
                ? new Intl.NumberFormat('en-US').format(Math.round(summary.avg_4week))
                : '—'}
            </div>
            <div className="card-sub">
              ETB/{unit || 'unit'}
              {summary?.avg_all && ` · Period avg: ${new Intl.NumberFormat('en-US').format(Math.round(summary.avg_all))}`}
            </div>
          </>
        )}
      </div>

      {/* Supply Signal */}
      <div className="summary-card" style={{ '--card-accent': 'var(--supply-sufficient)' }}>
        <div className="card-label">Supply Signal</div>
        {loading ? <Skeleton /> : (
          <>
            <div className="card-value" style={{ fontSize: 14, marginTop: 4 }}>
              <SupplyBadge signal={summary?.volume_signal} />
            </div>
            <div className="card-sub">
              {summary?.obs_count
                ? `${summary.obs_count.toLocaleString('en-US')} observations`
                : 'No filter applied'}
            </div>
          </>
        )}
      </div>
    </div>
  )
}
