import { NavLink, Outlet, useNavigate } from 'react-router-dom'
import { useAuth } from '../../contexts/AuthContext'
import { useTheme } from '../../contexts/ThemeContext'
import {
  LayoutDashboard, TrendingUp, Leaf, ShoppingBag,
  DollarSign, MessageCircle, User, Shield, DatabaseZap, Menu, X, Sun, Moon,
} from 'lucide-react'
import { useState } from 'react'
import ChatPanel from '../ChatPanel'

function navItems(role) {
  const base = [
    { to: '/app/dashboard', label: 'Dashboard',   Icon: LayoutDashboard },
    { to: '/app/market',    label: 'Market Intel', Icon: TrendingUp },
  ]
  const byRole = {
    farmer: [
      { to: '/app/crop-health', label: 'Crop Health',  Icon: Leaf },
      { to: '/app/inputs',      label: 'Input Intel',  Icon: ShoppingBag },
      { to: '/app/financial',   label: 'Financial',    Icon: DollarSign },
      { to: '/app/advisory',    label: 'AI Advisory',  Icon: MessageCircle },
      { to: '/app/profile',     label: 'My Profile',   Icon: User },
    ],
    agent: [
      { to: '/app/crop-health', label: 'Crop Health',  Icon: Leaf },
      { to: '/app/advisory',    label: 'AI Advisory',  Icon: MessageCircle },
      { to: '/app/profile',     label: 'My Profile',   Icon: User },
    ],
    trader: [
      { to: '/app/inputs',    label: 'Input Intel', Icon: ShoppingBag },
      { to: '/app/financial', label: 'Financial',   Icon: DollarSign },
      { to: '/app/advisory',  label: 'AI Advisory', Icon: MessageCircle },
      { to: '/app/profile',   label: 'My Profile',  Icon: User },
    ],
    admin: [
      { to: '/app/crop-health', label: 'Crop Health',  Icon: Leaf },
      { to: '/app/inputs',      label: 'Input Intel',  Icon: ShoppingBag },
      { to: '/app/financial',   label: 'Financial',    Icon: DollarSign },
      { to: '/app/advisory',    label: 'AI Advisory',  Icon: MessageCircle },
      { to: '/app/profile',     label: 'My Profile',   Icon: User },
      { to: '/app/admin',       label: 'Admin Panel',  Icon: Shield },
      { to: '/app/data-sync',   label: 'Data Sync',    Icon: DatabaseZap },
    ],
  }
  return [...base, ...(byRole[role] || byRole.farmer)]
}

export default function AppLayout() {
  const { user, logout } = useAuth()
  const { theme, toggleTheme } = useTheme()
  const navigate = useNavigate()
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  const items = navItems(user?.role)

  function handleLogout() {
    logout()
    navigate('/login')
  }

  const navLinkClass = ({ isActive }) =>
    `app-nav-item${isActive ? ' active' : ''}`

  return (
    <div className="app-layout-v2">
      {/* ── Header ── */}
      <header className="app-header">
        <button
          className="mobile-menu-btn"
          onClick={() => setMobileMenuOpen(o => !o)}
          aria-label="Toggle menu"
        >
          {mobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
        </button>

        <div className="app-logo">
          <div className="app-logo-icon">N</div>
          <div>
            <div className="app-logo-text">NMIS Agri-Platform</div>
            <div className="app-logo-sub">Ethiopia Agricultural Intelligence</div>
          </div>
        </div>

        <div className="header-spacer" />

        <button className="theme-toggle-btn" onClick={toggleTheme} title="Toggle theme">
          {theme === 'dark' ? <Sun size={16} /> : <Moon size={16} />}
        </button>

        <div className="user-badge">
          <div className="user-avatar">{user?.name?.[0]?.toUpperCase() || 'U'}</div>
          <div className="user-info">
            <div className="user-name">{user?.name}</div>
            <div className="user-role">{user?.role}</div>
          </div>
          <button className="logout-btn" onClick={handleLogout}>Sign out</button>
        </div>
      </header>

      {/* ── Sidebar (desktop) ── */}
      <nav className={`app-sidebar${mobileMenuOpen ? ' open' : ''}`}>
        <div className="sidebar-nav">
          {items.map(({ to, label, Icon }) => (
            <NavLink key={to} to={to} className={navLinkClass} onClick={() => setMobileMenuOpen(false)}>
              <Icon size={18} />
              <span>{label}</span>
            </NavLink>
          ))}
        </div>
        <div className="sidebar-footer">
          <div className="sidebar-user">
            <div className="user-avatar sm">{user?.name?.[0]?.toUpperCase() || 'U'}</div>
            <div>
              <div style={{ fontSize: 12, fontWeight: 600 }}>{user?.name}</div>
              <div style={{ fontSize: 11, color: 'var(--text-muted)', textTransform: 'capitalize' }}>{user?.role} · {user?.region || 'Ethiopia'}</div>
            </div>
          </div>
        </div>
      </nav>

      {mobileMenuOpen && (
        <div className="mobile-overlay" onClick={() => setMobileMenuOpen(false)} />
      )}

      {/* ── Main content ── */}
      <main className="app-main-v2">
        <Outlet />
      </main>

      {/* ── Bottom nav (mobile) ── */}
      <nav className="bottom-nav">
        {items.slice(0, 5).map(({ to, label, Icon }) => (
          <NavLink key={to} to={to} className={({ isActive }) => `bottom-nav-item${isActive ? ' active' : ''}`}>
            <Icon size={20} />
            <span>{label}</span>
          </NavLink>
        ))}
      </nav>

      <ChatPanel />
    </div>
  )
}
