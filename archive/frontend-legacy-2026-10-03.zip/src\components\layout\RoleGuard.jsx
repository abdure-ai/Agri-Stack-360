import { useAuth } from '../../contexts/AuthContext'

export default function RoleGuard({ role, children, fallback = null }) {
  const { hasRole } = useAuth()
  if (!hasRole(role)) return fallback
  return children
}
