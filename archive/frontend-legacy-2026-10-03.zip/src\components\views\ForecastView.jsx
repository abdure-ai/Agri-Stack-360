// components/views/ForecastView.jsx
// Integrates the LightGBM prediction API with historical regional price context.
import { useState, useEffect, useMemo } from 'react'
import {
  ComposedChart, Line, Area, XAxis, YAxis, CartesianGrid,
  Tooltip, Legend, ResponsiveContainer, ReferenceLine,
} from 'recharts'
import { api } from '../../api/client'
import { formatFullDate, formatAxisDate, formatETB } from '../../utils/formatters'
import { buildForecastRecommendation } from '../../utils/insights'

const WEEK_OPTIONS = [1, 2, 4, 8, 12]
const HIST_WINDOW  = 16   // weeks of historical context to show

const CONFIDENCE_META = {
  high:      { label: 'High confidence',     color: '#3ea87a', bg: 'rgba(62,168,122,0.12)' },
  medium:    { label: 'Medium confidence',   color: '#3ea6c4', bg: 'rgba(62,166,196,0.12)' },
  low:       { label: 'Low confidence',      color: '#e09b3a', bg: 'rgba(224,155,58,0.12)' },
  very_low:  { label: 'Very low confidence', color: '#e05c5c', bg: 'rgba(224,92,92,0.12)'  },
}

function makeTickFormatter(dates, maxTicks = 8) {
  const step = Math.max(1, Math.ceil(dates.length / maxTicks))
  const shown = new Set(dates.filter((_, i) => i % step === 0))
  return (val) => shown.has(val) ? formatAxisDate(val) : ''
}

function ForecastTooltip({ active, payload, label, unit }) {
  if (!active || !payload || !payload.length) return null
  const row = payload[0]?.payload || {}
  return (
    <div style={{
      background: 'var(--bg-elevated)',
      border: '1px solid var(--border-strong)',
      borderRadius: 8,
      padding: '12px 16px',
      fontSize: 12,
      boxShadow: 'var(--shadow-lg)',
      minWidth: 210,
    }}>
      <div style={{ color: 'var(--accent-light)', fontWeight: 600, marginBottom: 8, paddingBottom: 6, borderBottom: '1px solid var(--border-subtle)' }}>
        {formatFullDate(label)}
        {row.isForecast && <span style={{ marginLeft: 8, fontSize: 10, color: '#4dbb8a', fontWeight: 500 }}>FORECAST</span>}
      </div>
      {row.hist != null && (
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
          <span style={{ width: 8, height: 8, borderRadius: '50%', background: '#5b9bd5', flexShrink: 0 }} />
          <span style={{ color: 'var(--text-secondary)', flex: 1 }}>Actual price</span>
          <span style={{ color: 'var(--text-primary)', fontWeight: 700 }}>
            {Number(row.hist).toLocaleString('en-US')} ETB
          </span>
        </div>
      )}
      {row.fc_q50 != null && (
        <>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
            <span style={{ width: 8, height: 8, borderRadius: '50%', background: '#4dbb8a', flexShrink: 0 }} />
            <span style={{ color: 'var(--text-secondary)', flex: 1 }}>Forecast (median)</span>
            <span style={{ color: '#4dbb8a', fontWeight: 700 }}>
              {Number(row.fc_q50).toLocaleString('en-US')} ETB
            </span>
          </div>
          {row.fc_q10 != null && (
            <div style={{ fontSize: 11, color: 'var(--text-muted)', paddingLeft: 16 }}>
              80% interval:&nbsp;
              <span style={{ color: 'var(--text-secondary)' }}>{Number(row.fc_q10).toLocaleString('en-US')}</span>
              &nbsp;–&nbsp;
              <span style={{ color: 'var(--text-secondary)' }}>{Number(row.fc_q90).toLocaleString('en-US')}</span> ETB
            </div>
          )}
        </>
      )}
      {unit && <div style={{ color: 'var(--text-muted)', marginTop: 8, fontSize: 10, borderTop: '1px solid var(--border-subtle)', paddingTop: 6 }}>per {unit}</div>}
    </div>
  )
}

function RecommendationCard({ forecast, currentPrice, unit }) {
  const rec = useMemo(
    () => buildForecastRecommendation(forecast, currentPrice, unit),
    [forecast, currentPrice, unit]
  )
  if (!rec) return null

  return (
    <div className="recommendation-panel" style={{ '--rec-color': rec.color, borderTopColor: rec.color }}>
      {/* Header row */}
      <div className="rec-header">
        <div className="rec-header-left">
          <span className="rec-icon">◈</span>
          <span className="rec-title">Our Advice for You</span>
        </div>
        <div className="rec-action-badge" style={{ background: rec.bg, color: rec.color }}>
          {rec.label}
        </div>
      </div>

      {/* Summary sentence */}
      <p className="rec-summary">{rec.headline}</p>

      {/* Key stats strip */}
      <div className="rec-stats-row">
        <div className="rec-stat">
          <span className="rec-stat-label">Today's price</span>
          <span className="rec-stat-value">{formatETB(rec.currentPrice, unit)}</span>
        </div>
        <div className="rec-stat">
          <span className="rec-stat-label">Expected price in {forecast.weeks_ahead}W</span>
          <span className="rec-stat-value" style={{ color: rec.color }}>
            {formatETB(rec.forecastPrice, unit)}
          </span>
        </div>
        <div className="rec-stat">
          <span className="rec-stat-label">Price will change by</span>
          <span className="rec-stat-value" style={{ color: rec.changeColor }}>
            {rec.changePct > 0 ? '+' : ''}{rec.changePct.toFixed(1)}%
          </span>
        </div>
        <div className="rec-stat">
          <span className="rec-stat-label">How sure are we</span>
          <span className="rec-stat-value">{rec.uncertainty < 15 ? 'Fairly sure' : rec.uncertainty < 30 ? 'Somewhat sure' : 'Not very sure'}</span>
        </div>
      </div>

      {/* Bullet insights */}
      <div className="rec-bullets">
        {rec.bullets.map((b, i) => (
          <div key={i} className="rec-bullet">
            <span className="rec-bullet-dot" style={{ background: rec.color }} />
            <span>{b}</span>
          </div>
        ))}
      </div>

      {/* Disclaimer */}
      <div className="rec-disclaimer">
        This advice is based on past price data from {forecast.data_history_weeks} weeks of NMIS records ({forecast.history_start} to today).
        Forecasts are not guaranteed — always check prices at your local market before making a big decision.
      </div>
    </div>
  )
}

export default function ForecastView({ filters, regionalData, forecastOnline }) {
  const [weeksAhead, setWeeksAhead] = useState(4)
  const [forecast,   setForecast]   = useState(null)
  const [loading,    setLoading]    = useState(false)
  const [error,      setError]      = useState(null)

  const crop   = filters?.crop   || ''
  const region = filters?.region || ''

  // Fetch forecast whenever crop / region / weeksAhead change
  useEffect(() => {
    if (!crop || !region) { setForecast(null); return }
    setLoading(true)
    setError(null)
    api.forecast(crop, region, weeksAhead)
      .then(data => { setForecast(data); setLoading(false) })
      .catch(e  => { setError(e.message); setLoading(false) })
  }, [crop, region, weeksAhead])

  // Historical rows for the selected region (last HIST_WINDOW weeks)
  const histRows = useMemo(() => {
    const rows = (regionalData?.data || [])
      .filter(r => r.region === region)
      .sort((a, b) => a.date.localeCompare(b.date))
    return rows.slice(-HIST_WINDOW)
  }, [regionalData, region])

  // Build merged chart dataset
  const { chartData, cutoffDate, unit, yDomain } = useMemo(() => {
    const preds = forecast?.predictions || []
    const unit  = preds[0]?.unit || ''

    // Historical points
    const merged = histRows.map(r => ({ date: r.date, hist: r.price_avg, isForecast: false }))

    // Connection point: last historical → first forecast (seamless join)
    const lastHist = merged.length ? merged[merged.length - 1] : null
    const cutoff   = lastHist?.date || null

    if (lastHist && preds.length) {
      // Overwrite last hist point so it also seeds the forecast band
      merged[merged.length - 1] = {
        ...lastHist,
        fc_q50: lastHist.hist,
        fc_q10: lastHist.hist,
        fc_q90: lastHist.hist,
      }
    }

    // Forecast points
    preds.forEach(p => {
      merged.push({
        date:      p.forecast_date,
        hist:      null,
        fc_q50:    p.price_median_etb,
        fc_q10:    p.price_low_etb,
        fc_q90:    p.price_high_etb,
        isForecast: true,
      })
    })

    // Y-domain across all visible values with 8% padding
    const vals = merged.flatMap(r => [r.hist, r.fc_q10, r.fc_q90].filter(v => v != null))
    const yMin = vals.length ? Math.min(...vals) : 0
    const yMax = vals.length ? Math.max(...vals) : 100
    const pad  = (yMax - yMin) * 0.08
    const yDomain = [Math.max(0, Math.floor(yMin - pad)), Math.ceil(yMax + pad)]

    return { chartData: merged, cutoffDate: cutoff, unit, yDomain }
  }, [histRows, forecast])

  const dates          = chartData.map(r => r.date)
  const tickFormatter  = useMemo(() => makeTickFormatter(dates), [dates])
  const confMeta       = forecast ? (CONFIDENCE_META[forecast.confidence] || CONFIDENCE_META.low) : null
  const currentPrice   = histRows.length ? histRows[histRows.length - 1].price_avg : null

  // ── Empty states ──────────────────────────────────────────────────────────

  if (!crop) return (
    <div className="state-container">
      <div className="state-icon" style={{ fontSize: 36 }}>🌾</div>
      <div className="state-title">Select a commodity</div>
      <div className="state-sub">Choose a crop in the sidebar to see AI-powered price forecasts.</div>
    </div>
  )

  if (!region) return (
    <div className="state-container">
      <div className="state-icon" style={{ fontSize: 36 }}>📍</div>
      <div className="state-title">Select a region</div>
      <div className="state-sub">
        Forecasts are generated at the <strong>(crop, region)</strong> level.
        Choose a region in the sidebar to generate a price forecast.
      </div>
    </div>
  )

  if (!forecastOnline) return (
    <div className="state-container">
      <div className="state-icon" style={{ fontSize: 36 }}>🔌</div>
      <div className="state-title">Prediction service offline</div>
      <div className="state-sub">
        Start the prediction API to enable forecasts:
        <br /><br />
        <code style={{ color: 'var(--accent)', fontFamily: 'monospace', fontSize: 12 }}>
          uvicorn serving.predict_api:app --port 8001 --reload
        </code>
      </div>
    </div>
  )

  // ── Main render ────────────────────────────────────────────────────────────

  return (
    <div>
      {/* Toolbar */}
      <div className="chart-toolbar" style={{ marginBottom: 14 }}>
        <div style={{ flex: 1 }}>
          <div className="chart-title">
            {crop} — {region} · Price Forecast
          </div>
          <div className="chart-subtitle">
            LightGBM quantile regression · 80% prediction interval (q10–q90)
            {forecast?.price_level === 'producer' && (
              <span style={{ color: 'var(--color-producer)', marginLeft: 8 }}>· Producer prices (retail unavailable)</span>
            )}
          </div>
        </div>

        {/* Weeks-ahead selector */}
        <div className="week-selector">
          {WEEK_OPTIONS.map(w => (
            <button
              key={w}
              className={`week-btn${weeksAhead === w ? ' active' : ''}`}
              onClick={() => setWeeksAhead(w)}
            >
              {w}W
            </button>
          ))}
        </div>

        {/* Confidence badge */}
        {confMeta && !loading && (
          <div
            className="confidence-badge"
            style={{ color: confMeta.color, background: confMeta.bg, borderColor: confMeta.color + '40' }}
            title={forecast.confidence_note}
          >
            {forecast.confidence === 'high' ? '●' : forecast.confidence === 'medium' ? '◑' : '○'}
            &nbsp;{confMeta.label}
          </div>
        )}
      </div>

      {/* Chart */}
      {loading ? (
        <div className="state-container" style={{ padding: 40 }}>
          <div className="spinner" />
          <div className="state-sub">Generating forecast…</div>
        </div>
      ) : error ? (
        <div className="alert-notice" style={{ margin: '16px 0' }}>
          <span>⚠</span>
          <span>{error}</span>
        </div>
      ) : (
        <ResponsiveContainer width="100%" height={320}>
          <ComposedChart data={chartData} margin={{ top: 4, right: 20, left: 12, bottom: 4 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="var(--border-subtle)" vertical={false} />
            <XAxis
              dataKey="date"
              tickFormatter={tickFormatter}
              tick={{ fill: 'var(--text-muted)', fontSize: 11 }}
              axisLine={{ stroke: 'var(--border-subtle)' }}
              tickLine={false}
            />
            <YAxis
              domain={yDomain}
              tickFormatter={v => new Intl.NumberFormat('en-US', { notation: 'compact' }).format(v)}
              tick={{ fill: 'var(--text-muted)', fontSize: 11 }}
              axisLine={false}
              tickLine={false}
              width={62}
            />
            <Tooltip content={<ForecastTooltip unit={unit} />} />

            {/* Forecast band — q10 to q90 */}
            <Area
              type="monotone"
              dataKey="fc_q90"
              stroke="none"
              fill="#4dbb8a"
              fillOpacity={0.18}
              legendType="none"
              activeDot={false}
              isAnimationActive={false}
            />
            <Area
              type="monotone"
              dataKey="fc_q10"
              stroke="none"
              fill="var(--bg-surface)"
              fillOpacity={1}
              legendType="none"
              activeDot={false}
              isAnimationActive={false}
            />

            {/* Forecast median line */}
            <Line
              type="monotone"
              dataKey="fc_q50"
              name="Forecast (q50)"
              stroke="#4dbb8a"
              strokeWidth={2.5}
              strokeDasharray="6 3"
              dot={false}
              activeDot={{ r: 4, fill: '#4dbb8a', stroke: 'var(--bg-surface)', strokeWidth: 2 }}
              connectNulls={false}
              isAnimationActive={false}
            />

            {/* Historical price line */}
            <Line
              type="monotone"
              dataKey="hist"
              name="Historical price"
              stroke="#5b9bd5"
              strokeWidth={2}
              dot={false}
              activeDot={{ r: 4, fill: '#5b9bd5', stroke: 'var(--bg-surface)', strokeWidth: 2 }}
              connectNulls={false}
              isAnimationActive={false}
            />

            {/* Forecast start marker */}
            {cutoffDate && (
              <ReferenceLine
                x={cutoffDate}
                stroke="var(--border-strong)"
                strokeDasharray="4 2"
                label={{ value: 'Forecast', fill: 'var(--text-muted)', fontSize: 10, position: 'insideTopRight' }}
              />
            )}

            <Legend
              iconType="plainline"
              iconSize={16}
              wrapperStyle={{ fontSize: 11, color: 'var(--text-secondary)', paddingTop: 8 }}
            />
          </ComposedChart>
        </ResponsiveContainer>
      )}

      {/* Info row */}
      {forecast && !loading && !error && (
        <div className="forecast-info-row">
          <span>
            <span className="forecast-info-label">Model</span>
            LightGBM Quantile Regression
          </span>
          <span>
            <span className="forecast-info-label">History</span>
            {forecast.data_history_weeks} weeks (from {forecast.history_start})
          </span>
          <span>
            <span className="forecast-info-label">Markets</span>
            {forecast.markets_reporting_count} reporting
          </span>
          <span>
            <span className="forecast-info-label">Price level</span>
            {forecast.price_level}
          </span>
        </div>
      )}

      {/* Prediction table */}
      {forecast && !loading && !error && forecast.predictions?.length > 0 && (
        <div style={{ marginTop: 20 }}>
          <div style={{ fontSize: 11, fontWeight: 600, letterSpacing: '0.06em', textTransform: 'uppercase', color: 'var(--text-muted)', marginBottom: 8 }}>
            Forecast Table — ETB per {forecast.predictions[0]?.unit || 'unit'}
          </div>
          <table className="forecast-table">
            <thead>
              <tr>
                <th>Week</th>
                <th>Date</th>
                <th>Low (q10)</th>
                <th>Forecast (q50)</th>
                <th>High (q90)</th>
                <th>Interval width</th>
              </tr>
            </thead>
            <tbody>
              {forecast.predictions.map(p => {
                const spread = p.price_high_etb - p.price_low_etb
                const spreadPct = forecast.predictions[0]?.price_median_etb
                  ? ((spread / p.price_median_etb) * 100).toFixed(1)
                  : '—'
                return (
                  <tr key={p.step_week}>
                    <td className="forecast-table-week">W+{p.step_week}</td>
                    <td>{formatFullDate(p.forecast_date)}</td>
                    <td style={{ color: 'var(--text-muted)' }}>
                      {Number(p.price_low_etb).toLocaleString('en-US')}
                    </td>
                    <td style={{ color: '#4dbb8a', fontWeight: 700 }}>
                      {Number(p.price_median_etb).toLocaleString('en-US')}
                    </td>
                    <td style={{ color: 'var(--text-muted)' }}>
                      {Number(p.price_high_etb).toLocaleString('en-US')}
                    </td>
                    <td style={{ color: 'var(--text-muted)', fontSize: 11 }}>
                      ±{spreadPct}%
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>

          {/* Confidence note */}
          {confMeta && (
            <div className="forecast-confidence-note" style={{ borderColor: confMeta.color + '40', color: confMeta.color }}>
              <span style={{ fontSize: 13 }}>{forecast.confidence === 'high' ? '●' : forecast.confidence === 'medium' ? '◑' : '○'}</span>
              {forecast.confidence_note}
            </div>
          )}
        </div>
      )}

      {/* Recommendation card */}
      {forecast && !loading && !error && (
        <RecommendationCard
          forecast={forecast}
          currentPrice={currentPrice}
          unit={unit}
        />
      )}
    </div>
  )
}
