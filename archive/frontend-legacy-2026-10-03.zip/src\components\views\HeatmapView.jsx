// components/views/HeatmapView.jsx
import { useMemo, useRef, useState } from 'react'
import { heatColor, normalize } from '../../utils/colors'
import { formatAxisDate, formatFullDate } from '../../utils/formatters'

const MAX_MARKETS = 40
const MAX_DATES = 52   // ~1 year of weeks to keep cells readable

/**
 * Build a market × date matrix from flat price rows.
 * Returns { markets, dates, matrix: { [mktName]: { [date]: avg } } }
 */
function buildMatrix(data) {
  const marketMap = {}   // id -> name
  const dateSet = new Set()

  for (const row of data) {
    if (row.market_id) {
      marketMap[row.market_id] = row.market_name
      dateSet.add(row.date)
    }
  }

  const allDates = [...dateSet].sort()
  // Sample dates if too many
  let dates = allDates
  if (allDates.length > MAX_DATES) {
    const step = Math.ceil(allDates.length / MAX_DATES)
    dates = allDates.filter((_, i) => i % step === 0)
  }

  const dateSet2 = new Set(dates)

  // Build matrix
  const matrix = {}
  const globalPrices = []
  for (const row of data) {
    if (!row.market_id || !dateSet2.has(row.date)) continue
    const mName = row.market_name
    if (!matrix[mName]) matrix[mName] = {}
    matrix[mName][row.date] = row.price_avg
    if (row.price_avg !== null && row.price_avg !== undefined) {
      globalPrices.push(row.price_avg)
    }
  }

  let markets = Object.keys(matrix)
  if (markets.length > MAX_MARKETS) {
    markets = markets.slice(0, MAX_MARKETS)
  }

  const globalMin = Math.min(...globalPrices)
  const globalMax = Math.max(...globalPrices)

  return { markets, dates, matrix, globalMin, globalMax }
}

export default function HeatmapView({ data, filters, loading }) {
  const unit = data?.unit || ''
  const rawRows = data?.data || []
  const priceLevel = filters?.price_level || 'retail'

  const [tooltip, setTooltip] = useState(null)

  const { markets, dates, matrix, globalMin, globalMax } = useMemo(
    () => buildMatrix(rawRows),
    [rawRows]
  )

  const CELL_W = Math.max(10, Math.min(22, Math.floor(900 / (dates.length || 1))))
  const CELL_H = 16
  const LABEL_W = 130
  const DATE_ROW_H = 28

  if (loading) {
    return (
      <div className="state-container">
        <div className="spinner" />
        <div className="state-title">Loading heatmap data…</div>
      </div>
    )
  }

  if (!filters?.crop || !filters?.region) {
    return (
      <div className="state-container">
        <div className="state-icon">🟨</div>
        <div className="state-title">Select a commodity and region</div>
        <div className="state-sub">
          The heatmap shows price intensity across markets over time.
          Select a region to narrow to a manageable number of markets.
        </div>
      </div>
    )
  }

  if (rawRows.length === 0) {
    return (
      <div className="state-container">
        <div className="state-icon">🔍</div>
        <div className="state-title">No data for this selection</div>
        <div className="state-sub">
          {`Try selecting a different date range or price level with better coverage.`}
        </div>
      </div>
    )
  }

  const showDateStep = Math.max(1, Math.ceil(dates.length / 10))

  return (
    <div>
      <div className="chart-toolbar">
        <div>
          <div className="chart-title">
            {filters.crop} · {filters.region} — Price Heatmap
          </div>
          <div className="chart-subtitle">
            {priceLevel.charAt(0).toUpperCase() + priceLevel.slice(1)} price intensity ·
            {' '}{markets.length} markets × {dates.length} weeks ·
            Dark = lower / Warm = higher price
            {markets.length >= MAX_MARKETS && ` (capped at ${MAX_MARKETS} markets)`}
          </div>
        </div>
        {/* Color scale legend */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 10, color: 'var(--text-muted)' }}>
          <span>Low</span>
          <div style={{
            width: 80, height: 10, borderRadius: 3,
            background: 'linear-gradient(to right, rgb(42,75,115), rgb(45,120,160), rgb(180,130,60), rgb(210,90,50))',
          }} />
          <span>High</span>
        </div>
      </div>

      <div className="heatmap-container" style={{ position: 'relative' }}>
        {/* Tooltip */}
        {tooltip && (
          <div style={{
            position: 'fixed',
            left: tooltip.x + 12,
            top: tooltip.y - 40,
            background: 'var(--bg-elevated)',
            border: '1px solid var(--border-strong)',
            borderRadius: 5,
            padding: '6px 10px',
            fontSize: 11,
            pointerEvents: 'none',
            zIndex: 999,
            color: 'var(--text-primary)',
            whiteSpace: 'nowrap',
          }}>
            <strong>{tooltip.market}</strong> · {formatFullDate(tooltip.date)}<br />
            {tooltip.value !== null && tooltip.value !== undefined
              ? `${Number(tooltip.value).toLocaleString('en-US')} ETB/${unit}`
              : 'No data'}
          </div>
        )}

        <div style={{ display: 'flex' }}>
          {/* Market labels column */}
          <div style={{ width: LABEL_W, flexShrink: 0 }}>
            <div style={{ height: DATE_ROW_H }} /> {/* spacer for date row */}
            {markets.map(mkt => (
              <div key={mkt} style={{
                height: CELL_H + 1,
                display: 'flex',
                alignItems: 'center',
                fontSize: 10,
                color: 'var(--text-muted)',
                paddingRight: 8,
                overflow: 'hidden',
                textOverflow: 'ellipsis',
                whiteSpace: 'nowrap',
              }}>
                {mkt}
              </div>
            ))}
          </div>

          {/* Grid */}
          <div style={{ overflowX: 'auto', flex: 1 }}>
            {/* Date headers */}
            <div style={{ display: 'flex', height: DATE_ROW_H, alignItems: 'flex-end', paddingBottom: 4 }}>
              {dates.map((date, di) => (
                <div key={date} style={{
                  width: CELL_W,
                  flexShrink: 0,
                  fontSize: 9,
                  color: 'var(--text-muted)',
                  overflow: 'hidden',
                  whiteSpace: 'nowrap',
                  transform: 'rotate(-45deg)',
                  transformOrigin: 'left bottom',
                  paddingLeft: 2,
                }}>
                  {di % showDateStep === 0 ? formatAxisDate(date) : ''}
                </div>
              ))}
            </div>

            {/* Cells */}
            {markets.map(mkt => (
              <div key={mkt} style={{ display: 'flex', marginBottom: 1 }}>
                {dates.map(date => {
                  const val = matrix[mkt]?.[date]
                  const norm = (val !== null && val !== undefined)
                    ? normalize(val, globalMin, globalMax)
                    : null
                  const bg = norm !== null ? heatColor(norm) : 'var(--bg-elevated)'
                  return (
                    <div
                      key={date}
                      style={{
                        width: CELL_W,
                        height: CELL_H,
                        background: bg,
                        flexShrink: 0,
                        cursor: 'crosshair',
                        borderRadius: 1,
                        marginRight: 1,
                      }}
                      onMouseEnter={e => setTooltip({ market: mkt, date, value: val, x: e.clientX, y: e.clientY })}
                      onMouseLeave={() => setTooltip(null)}
                      onMouseMove={e => setTooltip(t => t ? { ...t, x: e.clientX, y: e.clientY } : null)}
                    />
                  )
                })}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
