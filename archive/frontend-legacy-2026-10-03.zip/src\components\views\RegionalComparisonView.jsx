// components/views/RegionalComparisonView.jsx
import { useMemo } from 'react'
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid,
  Tooltip, Legend, ResponsiveContainer,
} from 'recharts'
import { formatAxisDate, formatFullDate } from '../../utils/formatters'
import { REGION_COLORS } from '../../utils/colors'
import InsightsPanel from '../InsightsPanel'
import { analyzeRegional } from '../../utils/insights'

const REGIONS = ['Oromia', 'Amhara', 'SNNP', 'Sidama', 'South West', 'Tigray']

/** Pivot regional data: one row per date, columns per region */
function pivotRegional(data) {
  const byDate = {}
  for (const row of data) {
    if (!byDate[row.date]) byDate[row.date] = { date: row.date }
    byDate[row.date][row.region] = row.price_avg
  }
  return Object.values(byDate).sort((a, b) => a.date.localeCompare(b.date))
}

function makeTickFormatter(dates, maxTicks = 8) {
  const step = Math.max(1, Math.ceil(dates.length / maxTicks))
  const shown = new Set(dates.filter((_, i) => i % step === 0))
  return (val) => shown.has(val) ? formatAxisDate(val) : ''
}

function CustomTooltip({ active, payload, label, unit }) {
  if (!active || !payload || payload.length === 0) return null
  return (
    <div style={{
      background: 'var(--bg-elevated)',
      border: '1px solid var(--border-strong)',
      borderRadius: 6,
      padding: '10px 14px',
      fontSize: 12,
    }}>
      <div style={{ color: 'var(--text-secondary)', marginBottom: 8 }}>{formatFullDate(label)}</div>
      {payload
        .filter(p => p.value !== null && p.value !== undefined)
        .sort((a, b) => (b.value || 0) - (a.value || 0))
        .map((p, i) => (
          <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
            <span style={{ width: 8, height: 8, borderRadius: '50%', background: p.color, flexShrink: 0 }} />
            <span style={{ color: 'var(--text-secondary)', flex: 1, minWidth: 80 }}>{p.name}</span>
            <span style={{ color: 'var(--text-primary)', fontWeight: 600 }}>
              {Number(p.value).toLocaleString('en-US')} ETB
            </span>
          </div>
        ))}
      {unit && <div style={{ color: 'var(--text-muted)', marginTop: 6, fontSize: 10 }}>per {unit}</div>}
    </div>
  )
}

export default function RegionalComparisonView({ data, filters, loading }) {
  const unit = data?.unit || ''
  const rawRows = data?.data || []

  const chartData = useMemo(() => pivotRegional(rawRows), [rawRows])
  const dates = chartData.map(r => r.date)
  const tickFormatter = useMemo(() => makeTickFormatter(dates), [dates])

  const insights = useMemo(() => analyzeRegional(rawRows, filters, unit), [rawRows, filters, unit])

  // Only show regions that actually have data
  const activeRegions = useMemo(() => {
    const seen = new Set(rawRows.map(r => r.region))
    return REGIONS.filter(r => seen.has(r))
  }, [rawRows])

  if (loading) {
    return (
      <div className="state-container">
        <div className="spinner" />
        <div className="state-title">Loading regional data…</div>
      </div>
    )
  }

  if (!filters?.crop) {
    return (
      <div className="state-container">
        <div className="state-icon">🗺️</div>
        <div className="state-title">Select a commodity</div>
        <div className="state-sub">Regional comparison shows weekly averages across all 6 regions.</div>
      </div>
    )
  }

  if (rawRows.length === 0) {
    return (
      <div className="state-container">
        <div className="state-icon">🔍</div>
        <div className="state-title">No regional data for this selection</div>
        <div className="state-sub">
          {`Data for ${filters.crop} may not be available in all regions for the selected date range.`}
        </div>
      </div>
    )
  }

  const values = rawRows.map(r => r.price_avg).filter(Boolean)
  const yMin = Math.min(...values)
  const yMax = Math.max(...values)
  const yPad = (yMax - yMin) * 0.08
  const yDomain = [Math.max(0, Math.floor(yMin - yPad)), Math.ceil(yMax + yPad)]

  return (
    <div>
      <div className="chart-toolbar">
        <div>
          <div className="chart-title">
            {filters.crop} — Regional Price Comparison
          </div>
          <div className="chart-subtitle">
            {(filters.price_level || 'retail').charAt(0).toUpperCase() + (filters.price_level || 'retail').slice(1)} price weekly averages · ETB per {unit}
          </div>
        </div>
      </div>

      <ResponsiveContainer width="100%" height={340}>
        <LineChart data={chartData} margin={{ top: 4, right: 16, left: 12, bottom: 4 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="var(--border-subtle)" vertical={false} />
          <XAxis
            dataKey="date"
            tickFormatter={tickFormatter}
            tick={{ fill: 'var(--text-muted)', fontSize: 11 }}
            axisLine={{ stroke: 'var(--border-subtle)' }}
            tickLine={false}
          />
          <YAxis
            domain={yDomain}
            tickFormatter={v => new Intl.NumberFormat('en-US', { notation: 'compact' }).format(v)}
            tick={{ fill: 'var(--text-muted)', fontSize: 11 }}
            axisLine={false}
            tickLine={false}
            width={58}
          />
          <Tooltip content={<CustomTooltip unit={unit} />} />
          <Legend
            iconType="circle"
            iconSize={8}
            wrapperStyle={{ fontSize: 11, color: 'var(--text-secondary)' }}
          />
          {activeRegions.map(region => (
            <Line
              key={region}
              type="monotone"
              dataKey={region}
              name={region}
              stroke={REGION_COLORS[region]}
              strokeWidth={2}
              dot={false}
              activeDot={{ r: 4, stroke: 'var(--bg-surface)', strokeWidth: 2 }}
              connectNulls={false}
            />
          ))}
        </LineChart>
      </ResponsiveContainer>

      <InsightsPanel
        title="What This Means for You"
        headline={insights?.headline}
        bullets={insights?.bullets}
      />
    </div>
  )
}
