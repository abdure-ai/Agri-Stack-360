// components/views/SpreadView.jsx
import { useMemo } from 'react'
import {
  ComposedChart, Area, Line, XAxis, YAxis, CartesianGrid,
  Tooltip, Legend, ResponsiveContainer, ReferenceLine,
} from 'recharts'
import { formatAxisDate, formatFullDate } from '../../utils/formatters'
import InsightsPanel from '../InsightsPanel'
import { analyzeSpread } from '../../utils/insights'

function makeTickFormatter(dates, maxTicks = 8) {
  const step = Math.max(1, Math.ceil(dates.length / maxTicks))
  const shown = new Set(dates.filter((_, i) => i % step === 0))
  return (val) => shown.has(val) ? formatAxisDate(val) : ''
}

/** Pivot spread data by date (averaging across markets if multiple) */
function pivotSpread(data) {
  const byDate = {}
  for (const row of data) {
    if (!byDate[row.date]) {
      byDate[row.date] = { date: row.date, retail: [], producer: [], spread: [], spreadPct: [] }
    }
    if (row.retail_avg !== null) byDate[row.date].retail.push(row.retail_avg)
    if (row.producer_avg !== null) byDate[row.date].producer.push(row.producer_avg)
    if (row.spread !== null) byDate[row.date].spread.push(row.spread)
    if (row.spread_pct !== null) byDate[row.date].spreadPct.push(row.spread_pct)
  }

  return Object.values(byDate)
    .sort((a, b) => a.date.localeCompare(b.date))
    .map(r => {
      const avg = arr => arr.length > 0 ? arr.reduce((s, v) => s + v, 0) / arr.length : null
      return {
        date: r.date,
        retail_avg: avg(r.retail),
        producer_avg: avg(r.producer),
        spread: avg(r.spread),
        spread_pct: avg(r.spreadPct),
      }
    })
}

function CustomTooltip({ active, payload, label, unit }) {
  if (!active || !payload || payload.length === 0) return null
  const byName = {}
  payload.forEach(p => { byName[p.dataKey] = p.value })
  return (
    <div style={{
      background: 'var(--bg-elevated)',
      border: '1px solid var(--border-strong)',
      borderRadius: 6,
      padding: '10px 14px',
      fontSize: 12,
    }}>
      <div style={{ color: 'var(--text-secondary)', marginBottom: 8 }}>{formatFullDate(label)}</div>
      {[
        { key: 'retail_avg', label: 'Retail', color: 'var(--color-retail)' },
        { key: 'producer_avg', label: 'Producer', color: 'var(--color-producer)' },
        { key: 'spread', label: 'Spread (Retail − Producer)', color: '#e09b3a' },
      ].map(({ key, label, color }) => (
        byName[key] !== undefined && byName[key] !== null && (
          <div key={key} style={{ display: 'flex', gap: 8, marginBottom: 4, alignItems: 'center' }}>
            <span style={{ width: 8, height: 8, background: color, borderRadius: '50%', flexShrink: 0 }} />
            <span style={{ color: 'var(--text-secondary)', flex: 1 }}>{label}</span>
            <span style={{ color: 'var(--text-primary)', fontWeight: 600 }}>
              {Number(byName[key]).toLocaleString('en-US')} ETB
            </span>
          </div>
        )
      ))}
      {byName.spread_pct !== undefined && byName.spread_pct !== null && (
        <div style={{ color: 'var(--text-muted)', fontSize: 10, marginTop: 4 }}>
          Markup: {byName.spread_pct?.toFixed(1)}%
        </div>
      )}
      {unit && <div style={{ color: 'var(--text-muted)', marginTop: 4, fontSize: 10 }}>per {unit}</div>}
    </div>
  )
}

export default function SpreadView({ data, filters, loading }) {
  const unit = data?.unit || ''
  const rawRows = data?.data || []
  const producerCoverage = data?.producer_coverage_pct

  const chartData = useMemo(() => pivotSpread(rawRows), [rawRows])
  const dates = chartData.map(r => r.date)
  const tickFormatter = useMemo(() => makeTickFormatter(dates), [dates])
  const insights = useMemo(() => analyzeSpread(rawRows, filters, unit), [rawRows, filters, unit])

  if (loading) {
    return (
      <div className="state-container">
        <div className="spinner" />
        <div className="state-title">Loading spread data…</div>
      </div>
    )
  }

  if (!filters?.crop) {
    return (
      <div className="state-container">
        <div className="state-icon">📈</div>
        <div className="state-title">Select a commodity</div>
        <div className="state-sub">
          The spread chart shows retail price minus producer price over time — a proxy for market margin.
        </div>
      </div>
    )
  }

  if (rawRows.length === 0) {
    return (
      <div className="state-container">
        <div className="state-icon">🔍</div>
        <div className="state-title">Insufficient data for spread analysis</div>
        <div className="state-sub">
          Producer price data is required. Coverage for this selection:{' '}
          {producerCoverage !== undefined ? `${producerCoverage}%` : '—'}
          <br />Try selecting fewer markets or a date range after Dec 2022.
        </div>
      </div>
    )
  }

  const hasProducerData = chartData.some(r => r.producer_avg !== null)

  const values = chartData.flatMap(r => [r.retail_avg, r.producer_avg]).filter(Boolean)
  const yMin = Math.min(...values)
  const yMax = Math.max(...values)
  const yPad = (yMax - yMin) * 0.08
  const yDomain = [Math.max(0, Math.floor(yMin - yPad)), Math.ceil(yMax + yPad)]

  return (
    <div>
      {producerCoverage !== undefined && producerCoverage < 50 && (
        <div className="alert-notice">
          <span>⚠</span>
          <span>
            Producer price data coverage for this selection is <strong>{producerCoverage}%</strong>.
            The spread chart may have gaps where producer prices weren't reported.
          </span>
        </div>
      )}

      {!hasProducerData && (
        <div className="alert-notice">
          <span>⚠</span>
          <span>
            No producer price data found for this selection. Showing retail prices only.
            The spread (markup) chart requires producer price data to be meaningful.
          </span>
        </div>
      )}

      <div className="chart-toolbar">
        <div>
          <div className="chart-title">
            {filters.crop} — Producer-Retail Price Spread
          </div>
          <div className="chart-subtitle">
            Spread = Retail − Producer · ETB per {unit}
            {filters.region ? ` · ${filters.region}` : ''}
            {producerCoverage !== undefined && ` · Producer coverage: ${producerCoverage}%`}
          </div>
        </div>
      </div>

      {/* Main price lines chart */}
      <div style={{ marginBottom: 8 }}>
        <div style={{ fontSize: 11, color: 'var(--text-muted)', marginBottom: 6 }}>Price levels</div>
        <ResponsiveContainer width="100%" height={180}>
          <ComposedChart data={chartData} margin={{ top: 4, right: 16, left: 12, bottom: 4 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="var(--border-subtle)" vertical={false} />
            <XAxis dataKey="date" tick={false} axisLine={{ stroke: 'var(--border-subtle)' }} tickLine={false} />
            <YAxis
              domain={yDomain}
              tickFormatter={v => new Intl.NumberFormat('en-US', { notation: 'compact' }).format(v)}
              tick={{ fill: 'var(--text-muted)', fontSize: 11 }}
              axisLine={false}
              tickLine={false}
              width={58}
            />
            <Tooltip content={<CustomTooltip unit={unit} />} />
            <Legend iconType="circle" iconSize={8} wrapperStyle={{ fontSize: 11, color: 'var(--text-secondary)' }} />
            <Line type="monotone" dataKey="retail_avg" name="Retail" stroke="var(--color-retail)" strokeWidth={2} dot={false} connectNulls={false} />
            <Line type="monotone" dataKey="producer_avg" name="Producer" stroke="var(--color-producer)" strokeWidth={2} dot={false} strokeDasharray="5 3" connectNulls={false} />
          </ComposedChart>
        </ResponsiveContainer>
      </div>

      {/* Spread area chart */}
      <div>
        <div style={{ fontSize: 11, color: 'var(--text-muted)', marginBottom: 6 }}>Retail − Producer spread (ETB)</div>
        <ResponsiveContainer width="100%" height={140}>
          <ComposedChart data={chartData} margin={{ top: 4, right: 16, left: 12, bottom: 4 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="var(--border-subtle)" vertical={false} />
            <XAxis
              dataKey="date"
              tickFormatter={tickFormatter}
              tick={{ fill: 'var(--text-muted)', fontSize: 11 }}
              axisLine={{ stroke: 'var(--border-subtle)' }}
              tickLine={false}
            />
            <YAxis
              tickFormatter={v => new Intl.NumberFormat('en-US', { notation: 'compact' }).format(v)}
              tick={{ fill: 'var(--text-muted)', fontSize: 11 }}
              axisLine={false}
              tickLine={false}
              width={58}
            />
            <Tooltip content={<CustomTooltip unit={unit} />} />
            <ReferenceLine y={0} stroke="var(--border-strong)" strokeDasharray="4 2" />
            <Area
              type="monotone"
              dataKey="spread"
              name="Spread"
              stroke="#e09b3a"
              fill="#e09b3a"
              fillOpacity={0.2}
              dot={false}
              connectNulls={false}
            />
          </ComposedChart>
        </ResponsiveContainer>
      </div>

      <InsightsPanel
        title="Farm Price vs Shop Price"
        headline={insights?.headline}
        bullets={insights?.bullets}
      />
    </div>
  )
}
