// components/views/TimeSeriesView.jsx
import { useMemo, useState } from 'react'
import {
  ComposedChart, Line, Area, XAxis, YAxis, CartesianGrid,
  Tooltip, Legend, ResponsiveContainer, ReferenceLine,
} from 'recharts'
import { formatAxisDate, formatFullDate } from '../../utils/formatters'
import { MARKET_COLORS, PRICE_LEVEL_COLORS } from '../../utils/colors'
import InsightsPanel from '../InsightsPanel'
import { analyzeTimeSeries } from '../../utils/insights'

const BAND_FILL_OPACITY = 0.12

/**
 * Transform flat price data array (market-per-row) into a
 * date-keyed structure for Recharts: one row per date, columns for each market.
 */
function pivotByDate(data, marketIds) {
  if (!data || data.length === 0) return []
  const byDate = {}
  for (const row of data) {
    if (!byDate[row.date]) byDate[row.date] = { date: row.date, _avgs: [], _mins: [], _maxs: [] }
    if (row.market_id && marketIds.length > 0) {
      byDate[row.date][`avg_${row.market_id}`] = row.price_avg
      byDate[row.date][`min_${row.market_id}`] = row.price_min
      byDate[row.date][`max_${row.market_id}`] = row.price_max
    }
    if (row.price_avg !== null && row.price_avg !== undefined) byDate[row.date]._avgs.push(row.price_avg)
    if (row.price_min !== null && row.price_min !== undefined) byDate[row.date]._mins.push(row.price_min)
    if (row.price_max !== null && row.price_max !== undefined) byDate[row.date]._maxs.push(row.price_max)
  }
  return Object.values(byDate).map(d => {
    if (!marketIds || marketIds.length === 0) {
      d.avg_all = d._avgs.length ? d._avgs.reduce((a, b) => a + b, 0) / d._avgs.length : null
      d.min_all = d._mins.length ? Math.min(...d._mins) : null
      d.max_all = d._maxs.length ? Math.max(...d._maxs) : null
    }
    delete d._avgs; delete d._mins; delete d._maxs
    return d
  }).sort((a, b) => a.date.localeCompare(b.date))
}

/** Tick formatter for X axis — show every N-th label to avoid crowding */
function makeTickFormatter(dates, maxTicks = 8) {
  const step = Math.max(1, Math.ceil(dates.length / maxTicks))
  const shown = new Set(dates.filter((_, i) => i % step === 0))
  return (val) => shown.has(val) ? formatAxisDate(val) : ''
}

function CustomTooltip({ active, payload, label, unit, level, series }) {
  if (!active || !payload || payload.length === 0) return null
  const rowData = payload[0]?.payload || {}

  return (
    <div style={{
      background: 'var(--bg-elevated)',
      border: '1px solid var(--border-strong)',
      borderRadius: 8,
      padding: '12px 16px',
      fontSize: 12,
      boxShadow: 'var(--shadow-lg)',
      minWidth: 200,
    }}>
      <div style={{
        color: 'var(--accent-light)',
        fontWeight: 600,
        marginBottom: 8,
        paddingBottom: 6,
        borderBottom: '1px solid var(--border-subtle)',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
      }}>
        <span>📅 {formatFullDate(label)}</span>
        <span style={{ fontSize: 10, color: 'var(--text-muted)' }}>{level}</span>
      </div>

      {series.map(s => {
        const avgVal = rowData[`avg_${s.key}`]
        const minVal = rowData[`min_${s.key}`]
        const maxVal = rowData[`max_${s.key}`]

        if (avgVal === undefined || avgVal === null) return null

        return (
          <div key={s.key} style={{ marginBottom: 8 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 2 }}>
              <span style={{ width: 9, height: 9, borderRadius: '50%', background: s.color, flexShrink: 0 }} />
              <span style={{ color: 'var(--text-primary)', fontWeight: 600, flex: 1 }}>{s.label}</span>
              <span style={{ color: 'var(--accent-light)', fontWeight: 700, fontSize: 13 }}>
                {Number(avgVal).toLocaleString('en-US', { maximumFractionDigits: 2 })} ETB
              </span>
            </div>

            {(minVal !== undefined && maxVal !== undefined && minVal !== null && maxVal !== null) && (
              <div style={{ fontSize: 11, color: 'var(--text-muted)', paddingLeft: 17 }}>
                Range: <span style={{ color: 'var(--text-secondary)' }}>{Number(minVal).toLocaleString('en-US')}</span> – <span style={{ color: 'var(--text-secondary)' }}>{Number(maxVal).toLocaleString('en-US')}</span> ETB
              </div>
            )}
          </div>
        )
      })}

      {unit && (
        <div style={{ color: 'var(--text-muted)', marginTop: 6, fontSize: 10, borderTop: '1px stroke var(--border-subtle)', paddingTop: 4 }}>
          Standard Unit: <strong>ETB per {unit}</strong>
        </div>
      )}
    </div>
  )
}

export default function TimeSeriesView({ data, filters, loading, cropMeta }) {
  const [hoveredPoint, setHoveredPoint] = useState(null)
  const markets = filters?.markets || []
  const priceLevel = filters?.price_level || 'retail'
  const unit = data?.unit || ''
  const dataStart = data?.data_start

  const rawRows = data?.data || []
  const insights = useMemo(() => analyzeTimeSeries(rawRows, filters, unit), [rawRows, filters, unit])

  // Check if the selected date range is entirely before crop data starts
  const selectedStart = filters?.start_date
  const beforeCropData = dataStart && selectedStart && selectedStart < dataStart

  const chartData = useMemo(() => pivotByDate(rawRows, markets), [rawRows, markets])

  const dates = chartData.map(r => r.date)
  const tickFormatter = useMemo(() => makeTickFormatter(dates), [dates])

  // Determine which market series to render
  const series = useMemo(() => {
    if (markets.length > 0) {
      return markets.map((mId, i) => {
        const sample = rawRows.find(r => r.market_id === mId)
        return {
          key: String(mId),
          label: sample?.market_name || `Market ${mId}`,
          color: MARKET_COLORS[i % MARKET_COLORS.length],
        }
      })
    }
    // No market selected — show aggregated "all markets" line
    return [{ key: 'all', label: 'All Markets (avg)', color: PRICE_LEVEL_COLORS[priceLevel] }]
  }, [markets, rawRows, priceLevel])

  if (loading) {
    return (
      <div className="state-container">
        <div className="spinner" />
        <div className="state-title">Loading price data…</div>
      </div>
    )
  }

  if (!filters?.crop) {
    return (
      <div className="state-container">
        <div className="state-icon">📊</div>
        <div className="state-title">Select a commodity</div>
        <div className="state-sub">Use the filter sidebar to choose a crop, price level, and date range.</div>
      </div>
    )
  }

  if (rawRows.length === 0) {
    return (
      <div className="state-container">
        <div className="state-icon">🔍</div>
        <div className="state-title">No data for this selection</div>
        <div className="state-sub">
          {beforeCropData
            ? `Data for ${filters.crop} is only available from ${dataStart}. Try adjusting the date range.`
            : 'No price records match the current filters. Try broadening your selection.'}
        </div>
      </div>
    )
  }

  const yMin = Math.min(...rawRows.map(r => r.price_min).filter(Boolean))
  const yMax = Math.max(...rawRows.map(r => r.price_max).filter(Boolean))
  const yPad = (yMax - yMin) * 0.08
  const yDomain = [Math.max(0, Math.floor(yMin - yPad)), Math.ceil(yMax + yPad)]

  return (
    <div>
      {beforeCropData && (
        <div className="alert-notice">
          <span>⚠</span>
          <span>
            Data for <strong>{filters.crop}</strong> starts <strong>{dataStart}</strong>.
            The chart is showing data from that date forward.
          </span>
        </div>
      )}

      <div className="chart-toolbar">
        <div>
          <div className="chart-title">
            {filters.crop}{filters.variety ? ` · ${filters.variety}` : ''} — Price Trend
          </div>
          <div className="chart-subtitle">
            {priceLevel.charAt(0).toUpperCase() + priceLevel.slice(1)} price · ETB per {unit}
            {filters.region ? ` · ${filters.region}` : ''}
          </div>
        </div>

        {hoveredPoint && (
          <div style={{
            background: 'var(--accent-dim)',
            border: '1px solid var(--accent)',
            borderRadius: 'var(--radius-sm)',
            padding: '4px 10px',
            fontSize: 12,
            color: 'var(--accent-light)',
            display: 'flex',
            alignItems: 'center',
            gap: 10,
            fontWeight: 500,
          }}>
            <span>📍 {formatFullDate(hoveredPoint.date)}</span>
            {series.map(s => {
              const val = hoveredPoint.row[`avg_${s.key}`]
              if (val === undefined || val === null) return null
              return (
                <span key={s.key}>
                  <strong>{s.label}</strong>: {Number(val).toLocaleString('en-US')} ETB
                </span>
              )
            })}
          </div>
        )}
      </div>

      <ResponsiveContainer width="100%" height={340}>
        <ComposedChart
          data={chartData}
          margin={{ top: 4, right: 16, left: 12, bottom: 4 }}
          onMouseMove={(state) => {
            if (state && state.activePayload && state.activePayload.length) {
              setHoveredPoint({ date: state.activeLabel, row: state.activePayload[0].payload })
            } else {
              setHoveredPoint(null)
            }
          }}
          onMouseLeave={() => setHoveredPoint(null)}
        >
          <CartesianGrid strokeDasharray="3 3" stroke="var(--border-subtle)" vertical={false} />
          <XAxis
            dataKey="date"
            tickFormatter={tickFormatter}
            tick={{ fill: 'var(--text-muted)', fontSize: 11 }}
            axisLine={{ stroke: 'var(--border-subtle)' }}
            tickLine={false}
          />
          <YAxis
            domain={yDomain}
            tickFormatter={v => new Intl.NumberFormat('en-US', { notation: 'compact' }).format(v)}
            tick={{ fill: 'var(--text-muted)', fontSize: 11 }}
            axisLine={false}
            tickLine={false}
            width={58}
          />
          <Tooltip content={<CustomTooltip unit={unit} level={priceLevel} series={series} />} />
          {series.length > 1 && (
            <Legend
              iconType="circle"
              iconSize={8}
              wrapperStyle={{ fontSize: 11, color: 'var(--text-secondary)' }}
            />
          )}

          {/* Min-max shaded band for each series */}
          {series.map(({ key, color }) => (
            <Area
              key={`band_${key}`}
              type="monotone"
              dataKey={`max_${key}`}
              stroke="none"
              fill={color}
              fillOpacity={BAND_FILL_OPACITY}
              legendType="none"
              activeDot={false}
              isAnimationActive={false}
            />
          ))}
          {series.map(({ key, color }) => (
            <Area
              key={`band_lo_${key}`}
              type="monotone"
              dataKey={`min_${key}`}
              stroke="none"
              fill="var(--bg-surface)"
              fillOpacity={1}
              legendType="none"
              activeDot={false}
              isAnimationActive={false}
            />
          ))}

          {/* Main price lines */}
          {series.map(({ key, label, color }) => (
            <Line
              key={`line_${key}`}
              type="monotone"
              dataKey={`avg_${key}`}
              name={label}
              stroke={color}
              strokeWidth={2}
              dot={false}
              activeDot={{ r: 4, fill: color, stroke: 'var(--bg-surface)', strokeWidth: 2 }}
              connectNulls={false}
            />
          ))}
        </ComposedChart>
      </ResponsiveContainer>

      <InsightsPanel
        title="What This Chart Tells You"
        headline={insights?.headline}
        bullets={insights?.bullets}
      />
    </div>
  )
}
