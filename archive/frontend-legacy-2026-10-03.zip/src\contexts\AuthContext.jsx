import { createContext, useContext, useState, useCallback } from 'react'

const AuthContext = createContext(null)

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    try { return JSON.parse(sessionStorage.getItem('nmis_user')) } catch { return null }
  })
  const [token, setToken] = useState(() => sessionStorage.getItem('nmis_token') || null)

  const saveAuth = useCallback((accessToken, userData) => {
    sessionStorage.setItem('nmis_token', accessToken)
    sessionStorage.setItem('nmis_user', JSON.stringify(userData))
    setToken(accessToken)
    setUser(userData)
  }, [])

  const logout = useCallback(() => {
    sessionStorage.removeItem('nmis_token')
    sessionStorage.removeItem('nmis_user')
    setToken(null)
    setUser(null)
  }, [])

  const hasRole = useCallback((...roles) => roles.includes(user?.role), [user])

  return (
    <AuthContext.Provider value={{ user, token, saveAuth, logout, hasRole, isAuthenticated: !!user }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth must be used inside AuthProvider')
  return ctx
}
