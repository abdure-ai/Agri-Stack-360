import { useState, useEffect } from 'react'
import { api } from '../api/client'
import { Users, Wheat, AlertTriangle, CheckCircle } from 'lucide-react'

const ROLES = ['farmer', 'agent', 'trader', 'admin']

function RoleBadge({ role }) {
  return <span className="badge badge-role">{role}</span>
}

export default function AdminScreen() {
  const [stats, setStats] = useState(null)
  const [users, setUsers] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [updating, setUpdating] = useState(null)

  useEffect(() => {
    Promise.all([api.adminStats(), api.adminUsers()])
      .then(([s, u]) => { setStats(s); setUsers(u) })
      .catch(e => setError('Failed to load admin data.'))
      .finally(() => setLoading(false))
  }, [])

  async function changeRole(userId, role) {
    setUpdating(userId)
    try {
      await api.setUserRole(userId, role)
      setUsers(prev => prev.map(u => u.id === userId ? { ...u, role } : u))
    } catch (e) {
      alert(e.message)
    } finally {
      setUpdating(null)
    }
  }

  async function toggleActive(userId, is_active) {
    setUpdating(userId)
    try {
      await api.setUserActive(userId, is_active)
      setUsers(prev => prev.map(u => u.id === userId ? { ...u, is_active: is_active ? 1 : 0 } : u))
    } catch (e) {
      alert(e.message)
    } finally {
      setUpdating(null)
    }
  }

  if (loading) return <div className="loading-state">Loading admin panel…</div>
  if (error)   return <div className="form-error">{error}</div>

  return (
    <div>
      <div className="screen-header">
        <div className="screen-title">Admin Panel</div>
        <div className="screen-subtitle">Platform management — users, roles, and statistics</div>
      </div>

      {/* Stats */}
      {stats && (
        <div className="grid-4" style={{ marginBottom: 28 }}>
          <div className="stat-card">
            <div className="stat-label">Total Users</div>
            <div className="stat-value">{stats.total_users}</div>
          </div>
          <div className="stat-card">
            <div className="stat-label">Total Farms</div>
            <div className="stat-value">{stats.total_farms}</div>
          </div>
          <div className="stat-card">
            <div className="stat-label">Open Health Reports</div>
            <div className="stat-value" style={{ color: stats.open_health_reports > 0 ? '#e09b3a' : 'var(--positive)' }}>{stats.open_health_reports}</div>
          </div>
          <div className="stat-card">
            <div className="stat-label">Resolved Reports</div>
            <div className="stat-value" style={{ color: 'var(--positive)' }}>{stats.resolved_health_reports}</div>
          </div>
        </div>
      )}

      {/* Role breakdown */}
      {stats?.users_by_role && (
        <div className="card" style={{ marginBottom: 24 }}>
          <div className="section-title">Users by Role</div>
          <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap' }}>
            {Object.entries(stats.users_by_role).map(([role, count]) => (
              <div key={role} style={{ padding: '8px 16px', background: 'var(--bg-elevated)', borderRadius: 'var(--radius-md)', textAlign: 'center' }}>
                <div style={{ fontSize: 20, fontWeight: 700, color: 'var(--accent)' }}>{count}</div>
                <div style={{ fontSize: 11, color: 'var(--text-muted)', textTransform: 'capitalize' }}>{role}s</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Users table */}
      <div className="section-title">All Users ({users.length})</div>
      <div style={{ overflowX: 'auto' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
          <thead>
            <tr style={{ borderBottom: '1px solid var(--border-medium)', textAlign: 'left' }}>
              {['Name', 'Phone', 'Role', 'Region', 'Farms', 'Joined', 'Status', 'Actions'].map(h => (
                <th key={h} style={{ padding: '8px 12px', color: 'var(--text-muted)', fontWeight: 600, fontSize: 11, textTransform: 'uppercase', letterSpacing: '0.04em', whiteSpace: 'nowrap' }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {users.map(u => (
              <tr key={u.id} style={{ borderBottom: '1px solid var(--border-subtle)', opacity: u.is_active ? 1 : 0.5 }}>
                <td style={{ padding: '10px 12px', fontWeight: 600, color: 'var(--text-primary)' }}>{u.name}</td>
                <td style={{ padding: '10px 12px', color: 'var(--text-muted)' }}>{u.phone}</td>
                <td style={{ padding: '10px 12px' }}>
                  <select
                    value={u.role}
                    onChange={e => changeRole(u.id, e.target.value)}
                    disabled={updating === u.id}
                    style={{ background: 'var(--bg-elevated)', border: '1px solid var(--border-medium)', borderRadius: 'var(--radius-sm)', color: 'var(--accent)', fontSize: 12, padding: '3px 6px', cursor: 'pointer' }}
                  >
                    {ROLES.map(r => <option key={r} value={r}>{r}</option>)}
                  </select>
                </td>
                <td style={{ padding: '10px 12px', color: 'var(--text-secondary)' }}>{u.region || '—'}</td>
                <td style={{ padding: '10px 12px', color: 'var(--text-secondary)' }}>{u.farm_count || 0}</td>
                <td style={{ padding: '10px 12px', color: 'var(--text-muted)', whiteSpace: 'nowrap' }}>{u.created_at?.slice(0, 10)}</td>
                <td style={{ padding: '10px 12px' }}>
                  <span style={{ fontSize: 11, fontWeight: 600, color: u.is_active ? '#3ea87a' : '#e05c5c' }}>
                    {u.is_active ? 'Active' : 'Inactive'}
                  </span>
                </td>
                <td style={{ padding: '10px 12px' }}>
                  <button
                    className="btn-secondary"
                    style={{ fontSize: 11, padding: '3px 8px', color: u.is_active ? 'var(--negative)' : 'var(--positive)' }}
                    disabled={updating === u.id}
                    onClick={() => toggleActive(u.id, !u.is_active)}
                  >
                    {u.is_active ? 'Deactivate' : 'Activate'}
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
