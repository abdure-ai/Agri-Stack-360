import { useState, useRef, useEffect } from 'react'
import { useAuth } from '../contexts/AuthContext'
import { api } from '../api/client'
import { Send } from 'lucide-react'

export default function AdvisoryScreen() {
  const { user } = useAuth()
  const [messages, setMessages] = useState([
    {
      role: 'assistant',
      content: `Hello${user ? `, ${user.name}` : ''}! I am your agricultural AI advisor. I have access to live Ethiopian market prices and can help you with crop advice, market analysis, input selection, and more. You can also ask me in Amharic (አማርኛ). How can I help you today?`,
    },
  ])
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)
  const bottomRef = useRef(null)

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  async function handleSend() {
    const text = input.trim()
    if (!text || loading) return
    setInput('')

    const history = messages.slice(-10).map(m => ({ role: m.role, content: m.content }))
    setMessages(prev => [...prev, { role: 'user', content: text }])
    setLoading(true)

    try {
      const res = await api.chat(text, history)
      setMessages(prev => [...prev, { role: 'assistant', content: res.reply || res.error || 'No response.' }])
    } catch {
      setMessages(prev => [...prev, { role: 'assistant', content: 'Connection error. Please check the server.' }])
    } finally {
      setLoading(false)
    }
  }

  function handleKey(e) {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend() }
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: 'calc(100vh - 100px)' }}>
      <div className="screen-header">
        <div className="screen-title">AI Advisory</div>
        <div className="screen-subtitle">Powered by Gemini · Live NMIS price context · Amharic supported</div>
      </div>

      {/* Messages */}
      <div style={{
        flex: 1, overflowY: 'auto', padding: '0 0 8px',
        display: 'flex', flexDirection: 'column', gap: 12,
      }}>
        {messages.map((m, i) => (
          <div
            key={i}
            style={{
              display: 'flex',
              justifyContent: m.role === 'user' ? 'flex-end' : 'flex-start',
            }}
          >
            <div style={{
              maxWidth: '75%',
              background: m.role === 'user' ? 'var(--accent)' : 'var(--bg-surface)',
              color: m.role === 'user' ? 'white' : 'var(--text-primary)',
              border: m.role === 'assistant' ? '1px solid var(--border-subtle)' : 'none',
              borderRadius: m.role === 'user' ? '18px 18px 4px 18px' : '4px 18px 18px 18px',
              padding: '12px 16px',
              fontSize: 14,
              lineHeight: 1.6,
              whiteSpace: 'pre-wrap',
              boxShadow: 'var(--shadow-sm)',
            }}>
              {m.content}
            </div>
          </div>
        ))}
        {loading && (
          <div style={{ display: 'flex', justifyContent: 'flex-start' }}>
            <div style={{ background: 'var(--bg-surface)', border: '1px solid var(--border-subtle)', borderRadius: '4px 18px 18px 18px', padding: '12px 16px', fontSize: 14, color: 'var(--text-muted)' }}>
              Thinking…
            </div>
          </div>
        )}
        <div ref={bottomRef} />
      </div>

      {/* Input */}
      <div style={{
        display: 'flex', gap: 8, paddingTop: 12,
        borderTop: '1px solid var(--border-subtle)',
      }}>
        <textarea
          style={{
            flex: 1, minHeight: 44, maxHeight: 160, resize: 'vertical',
            background: 'var(--bg-elevated)', border: '1px solid var(--border-medium)',
            borderRadius: 'var(--radius-md)', color: 'var(--text-primary)',
            fontSize: 14, padding: '10px 14px', outline: 'none',
            fontFamily: 'inherit',
          }}
          placeholder="Ask about prices, crops, inputs, loans… or type in Amharic"
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={handleKey}
        />
        <button
          onClick={handleSend}
          disabled={!input.trim() || loading}
          style={{
            background: 'var(--accent)', border: 'none', borderRadius: 'var(--radius-md)',
            color: 'white', padding: '0 16px', cursor: 'pointer',
            display: 'flex', alignItems: 'center', gap: 6,
            opacity: !input.trim() || loading ? 0.5 : 1,
          }}
        >
          <Send size={16} />
        </button>
      </div>
    </div>
  )
}
