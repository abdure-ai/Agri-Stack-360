import { useState, useEffect } from 'react'
import { api } from '../api/client'
import { Leaf, Plus, CheckCircle, AlertTriangle, XCircle, ChevronRight } from 'lucide-react'

function SeverityBadge({ severity }) {
  const cls = { low: 'badge-low', moderate: 'badge-warning', high: 'badge-high', critical: 'badge-critical' }
  return <span className={`badge ${cls[severity] || 'badge-low'}`}>{severity}</span>
}

function FarmSelector({ farms, selectedId, onSelect }) {
  return (
    <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 16 }}>
      {farms.map(f => (
        <button
          key={f.id}
          className={`chip-filter${selectedId === f.id ? ' active' : ''}`}
          onClick={() => onSelect(f.id)}
        >
          {f.field_name} — {f.crop_name}
        </button>
      ))}
    </div>
  )
}

export default function CropHealthScreen() {
  const [farms, setFarms] = useState([])
  const [selectedFarm, setSelectedFarm] = useState(null)
  const [reports, setReports] = useState([])
  const [tab, setTab] = useState('diagnose')
  const [description, setDescription] = useState('')
  const [diagnosis, setDiagnosis] = useState(null)
  const [diagnosing, setDiagnosing] = useState(false)
  const [saving, setSaving] = useState(false)
  const [saved, setSaved] = useState(false)
  const [error, setError] = useState('')

  useEffect(() => {
    api.getFarms().then(data => {
      setFarms(data)
      if (data.length > 0) setSelectedFarm(data[0])
    }).catch(() => {})
  }, [])

  useEffect(() => {
    if (selectedFarm) {
      api.getHealthReports(selectedFarm.id).then(setReports).catch(() => {})
    }
  }, [selectedFarm])

  async function handleDiagnose() {
    if (!selectedFarm || !description.trim()) return
    setError('')
    setDiagnosing(true)
    setDiagnosis(null)
    setSaved(false)
    try {
      const result = await api.diagnose({ farm_id: selectedFarm.id, description, crop: selectedFarm.crop_name })
      setDiagnosis(result)
    } catch (e) {
      setError('Diagnosis failed. Is the server running?')
    } finally {
      setDiagnosing(false)
    }
  }

  async function handleSave() {
    if (!diagnosis) return
    setSaving(true)
    try {
      await api.saveHealthReport({
        farm_id: diagnosis.farm_id,
        disease: diagnosis.disease,
        pathogen: diagnosis.pathogen,
        severity: diagnosis.severity,
        confidence: diagnosis.confidence,
        visual_cues: diagnosis.visual_cues,
        recommended_action: diagnosis.recommended_action,
        follow_up_date: diagnosis.follow_up_date,
        ai_explanation: diagnosis.ai_explanation,
      })
      setSaved(true)
      const updated = await api.getHealthReports(selectedFarm.id)
      setReports(updated)
    } catch (e) {
      setError('Failed to save report.')
    } finally {
      setSaving(false)
    }
  }

  async function handleResolve(reportId) {
    try {
      await api.resolveReport(reportId)
      setReports(prev => prev.map(r => r.id === reportId ? { ...r, resolved: 1 } : r))
    } catch {}
  }

  return (
    <div>
      <div className="screen-header">
        <div className="screen-title">Crop Health</div>
        <div className="screen-subtitle">Diagnose crop diseases and track farm health reports</div>
      </div>

      {farms.length === 0 ? (
        <div className="card empty-state">
          <div className="empty-state-icon"><Leaf size={32} style={{ color: 'var(--text-muted)' }} /></div>
          <div className="empty-state-text">No farms registered. Add a farm from your Profile to get started.</div>
        </div>
      ) : (
        <>
          <FarmSelector farms={farms} selectedId={selectedFarm?.id} onSelect={id => setSelectedFarm(farms.find(f => f.id === id))} />

          {/* Tabs */}
          <div style={{ display: 'flex', gap: 4, marginBottom: 20, borderBottom: '1px solid var(--border-subtle)', paddingBottom: 2 }}>
            {['diagnose', 'history'].map(t => (
              <button
                key={t}
                onClick={() => setTab(t)}
                style={{
                  background: 'none', border: 'none', cursor: 'pointer',
                  padding: '8px 16px', fontSize: 13, fontWeight: 600,
                  color: tab === t ? 'var(--accent)' : 'var(--text-muted)',
                  borderBottom: tab === t ? '2px solid var(--accent)' : '2px solid transparent',
                  transition: 'var(--transition)',
                }}
              >
                {t === 'diagnose' ? 'AI Diagnosis' : `Report History (${reports.length})`}
              </button>
            ))}
          </div>

          {tab === 'diagnose' && (
            <div className="grid-2" style={{ gap: 20, alignItems: 'start' }}>
              {/* Input */}
              <div className="card">
                <div className="section-title">Describe the symptoms</div>
                {selectedFarm && (
                  <div style={{ marginBottom: 12, padding: '10px 12px', background: 'var(--bg-elevated)', borderRadius: 'var(--radius-md)', fontSize: 13 }}>
                    <strong>{selectedFarm.field_name}</strong> — {selectedFarm.crop_name}
                    {selectedFarm.variety && ` (${selectedFarm.variety})`}
                  </div>
                )}
                <textarea
                  style={{
                    width: '100%', minHeight: 140,
                    background: 'var(--bg-elevated)', border: '1px solid var(--border-medium)',
                    borderRadius: 'var(--radius-md)', color: 'var(--text-primary)',
                    fontSize: 14, padding: '10px 12px', resize: 'vertical', outline: 'none',
                  }}
                  placeholder="e.g. Long gray-green lesions on lower leaves, lesion borders are wavy, some leaves turning brown..."
                  value={description}
                  onChange={e => setDescription(e.target.value)}
                />
                {error && <div className="form-error" style={{ marginTop: 8 }}>{error}</div>}
                <button
                  className="btn-primary"
                  style={{ marginTop: 12 }}
                  disabled={!description.trim() || diagnosing}
                  onClick={handleDiagnose}
                >
                  {diagnosing ? 'Analyzing…' : 'Diagnose with AI'}
                </button>
              </div>

              {/* Result */}
              <div>
                {diagnosing && <div className="loading-state">Analyzing symptoms…</div>}
                {diagnosis && (
                  <div className="card">
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 16 }}>
                      <div>
                        <div style={{ fontWeight: 700, fontSize: 16, color: 'var(--text-primary)', marginBottom: 4 }}>{diagnosis.disease}</div>
                        {diagnosis.pathogen && <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>{diagnosis.pathogen}</div>}
                      </div>
                      <SeverityBadge severity={diagnosis.severity} />
                    </div>

                    <div style={{ display: 'flex', gap: 16, marginBottom: 16 }}>
                      <div style={{ textAlign: 'center' }}>
                        <div style={{ fontSize: 24, fontWeight: 700, color: 'var(--accent)' }}>{diagnosis.confidence}%</div>
                        <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>confidence</div>
                      </div>
                      {diagnosis.follow_up_date && (
                        <div>
                          <div style={{ fontSize: 11, color: 'var(--text-muted)', marginBottom: 2 }}>Follow-up by</div>
                          <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--text-primary)' }}>{diagnosis.follow_up_date}</div>
                        </div>
                      )}
                    </div>

                    {diagnosis.visual_cues?.length > 0 && (
                      <div style={{ marginBottom: 12 }}>
                        <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-secondary)', marginBottom: 6, textTransform: 'uppercase', letterSpacing: '0.04em' }}>Visual Signs</div>
                        {diagnosis.visual_cues.map((cue, i) => (
                          <div key={i} style={{ fontSize: 13, color: 'var(--text-primary)', padding: '4px 0', borderBottom: '1px solid var(--border-subtle)', display: 'flex', gap: 8 }}>
                            <span style={{ color: 'var(--text-muted)' }}>•</span> {cue}
                          </div>
                        ))}
                      </div>
                    )}

                    {diagnosis.recommended_action && (
                      <div style={{ background: 'rgba(62,168,122,0.08)', border: '1px solid rgba(62,168,122,0.2)', borderRadius: 'var(--radius-md)', padding: '10px 12px', marginBottom: 12 }}>
                        <div style={{ fontSize: 11, fontWeight: 600, color: '#3ea87a', marginBottom: 4, textTransform: 'uppercase' }}>Recommended Action</div>
                        <div style={{ fontSize: 13, color: 'var(--text-primary)' }}>{diagnosis.recommended_action}</div>
                      </div>
                    )}

                    {diagnosis.ai_explanation && (
                      <div className="ai-card" style={{ marginBottom: 12 }}>
                        <div className="ai-label">AI Explanation</div>
                        <div className="ai-text">{diagnosis.ai_explanation}</div>
                      </div>
                    )}

                    {saved ? (
                      <div style={{ display: 'flex', alignItems: 'center', gap: 6, color: '#3ea87a', fontSize: 13, fontWeight: 600 }}>
                        <CheckCircle size={16} /> Report saved
                      </div>
                    ) : (
                      <button className="btn-primary" onClick={handleSave} disabled={saving}>
                        {saving ? 'Saving…' : 'Save to Health Reports'}
                      </button>
                    )}
                  </div>
                )}
                {!diagnosis && !diagnosing && (
                  <div className="card empty-state">
                    <div className="empty-state-icon"><Leaf size={28} style={{ color: 'var(--text-muted)' }} /></div>
                    <div className="empty-state-text">Describe the symptoms and press Diagnose</div>
                  </div>
                )}
              </div>
            </div>
          )}

          {tab === 'history' && (
            <div>
              {reports.length === 0 ? (
                <div className="card empty-state">
                  <div className="empty-state-icon"><CheckCircle size={28} style={{ color: 'var(--positive)' }} /></div>
                  <div className="empty-state-text">No health reports for this farm yet.</div>
                </div>
              ) : (
                <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                  {reports.map(r => (
                    <div key={r.id} className="card" style={{ opacity: r.resolved ? 0.6 : 1 }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                        <div>
                          <div style={{ fontWeight: 600, color: 'var(--text-primary)', marginBottom: 4 }}>{r.disease}</div>
                          <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>{r.created_at?.slice(0, 10)}</div>
                        </div>
                        <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                          <SeverityBadge severity={r.severity} />
                          {r.resolved
                            ? <span style={{ fontSize: 12, color: '#3ea87a', fontWeight: 600 }}>✓ Resolved</span>
                            : <button className="btn-secondary" style={{ fontSize: 11, padding: '3px 10px' }} onClick={() => handleResolve(r.id)}>Mark resolved</button>
                          }
                        </div>
                      </div>
                      {r.recommended_action && !r.resolved && (
                        <div style={{ marginTop: 8, fontSize: 13, color: 'var(--text-secondary)' }}>{r.recommended_action}</div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </>
      )}
    </div>
  )
}
