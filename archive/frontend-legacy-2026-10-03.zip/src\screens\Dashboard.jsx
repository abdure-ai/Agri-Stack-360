import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../contexts/AuthContext'
import { api } from '../api/client'
import { Leaf, TrendingUp, ShoppingBag, DollarSign, MessageCircle, AlertTriangle, CheckCircle } from 'lucide-react'

function greet() {
  const h = new Date().getHours()
  if (h < 12) return 'Good morning'
  if (h < 17) return 'Good afternoon'
  return 'Good evening'
}

function FarmCard({ farm, onClick }) {
  const statusClass = farm.status === 'healthy' ? 'badge-healthy' : farm.status === 'warning' ? 'badge-warning' : 'badge-critical'
  return (
    <div className="card" style={{ cursor: 'pointer' }} onClick={onClick}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 8 }}>
        <div style={{ fontWeight: 600, color: 'var(--text-primary)', fontSize: 14 }}>{farm.field_name}</div>
        <span className={`badge ${statusClass}`}>{farm.status}</span>
      </div>
      <div style={{ fontSize: 13, color: 'var(--text-secondary)' }}>{farm.crop_name}{farm.variety ? ` · ${farm.variety}` : ''}</div>
      {farm.area_ha && <div style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: 4 }}>{farm.area_ha} ha</div>}
      {farm.notes && <div style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: 6, borderTop: '1px solid var(--border-subtle)', paddingTop: 6 }}>{farm.notes}</div>}
    </div>
  )
}

function QuickAction({ icon: Icon, label, color, onClick }) {
  return (
    <button
      onClick={onClick}
      style={{
        background: 'var(--bg-surface)',
        border: '1px solid var(--border-subtle)',
        borderRadius: 'var(--radius-lg)',
        padding: '16px',
        cursor: 'pointer',
        textAlign: 'center',
        transition: 'var(--transition)',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        gap: 8,
      }}
      onMouseOver={e => e.currentTarget.style.borderColor = color}
      onMouseOut={e => e.currentTarget.style.borderColor = 'var(--border-subtle)'}
    >
      <div style={{ width: 40, height: 40, borderRadius: '50%', background: `${color}20`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <Icon size={20} style={{ color }} />
      </div>
      <span style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-secondary)' }}>{label}</span>
    </button>
  )
}

export default function Dashboard() {
  const { user, hasRole } = useAuth()
  const navigate = useNavigate()
  const [farms, setFarms] = useState([])
  const [creditScore, setCreditScore] = useState(null)
  const [loadingFarms, setLoadingFarms] = useState(true)

  useEffect(() => {
    if (hasRole('farmer', 'agent', 'admin')) {
      api.getFarms()
        .then(setFarms)
        .catch(() => {})
        .finally(() => setLoadingFarms(false))
    } else {
      setLoadingFarms(false)
    }

    if (hasRole('farmer')) {
      api.creditProfile().then(d => setCreditScore(d.score)).catch(() => {})
    }
  }, [hasRole])

  const warningFarms = farms.filter(f => f.status === 'warning' || f.status === 'critical')

  return (
    <div>
      {/* Greeting */}
      <div className="screen-header" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <div>
          <div className="screen-title">{greet()}, {user?.name?.split(' ')[0]} 👋</div>
          <div className="screen-subtitle" style={{ textTransform: 'capitalize' }}>{user?.role} · {user?.region || 'Ethiopia'}</div>
        </div>
        {creditScore !== null && (
          <div className="stat-card" style={{ padding: '12px 16px', minWidth: 100, textAlign: 'center' }}>
            <div className="stat-label">Credit Score</div>
            <div className="stat-value" style={{ fontSize: 24, color: creditScore >= 60 ? 'var(--positive)' : creditScore >= 40 ? '#e09b3a' : 'var(--negative)' }}>{creditScore}</div>
            <div className="stat-sub">out of 100</div>
          </div>
        )}
      </div>

      {/* Alerts */}
      {warningFarms.length > 0 && (
        <div style={{ background: 'rgba(224,155,58,0.1)', border: '1px solid rgba(224,155,58,0.3)', borderRadius: 'var(--radius-lg)', padding: '12px 16px', marginBottom: 20, display: 'flex', gap: 10, alignItems: 'flex-start' }}>
          <AlertTriangle size={18} style={{ color: '#e09b3a', flexShrink: 0, marginTop: 1 }} />
          <div>
            <div style={{ fontWeight: 600, fontSize: 13, color: '#e09b3a' }}>Action needed</div>
            <div style={{ fontSize: 13, color: 'var(--text-secondary)', marginTop: 2 }}>
              {warningFarms.length} farm{warningFarms.length > 1 ? 's' : ''} need attention: {warningFarms.map(f => f.field_name).join(', ')}
            </div>
          </div>
        </div>
      )}

      {/* Quick actions */}
      <div className="section-title">Quick Actions</div>
      <div className="grid-4" style={{ marginBottom: 28 }}>
        <QuickAction icon={TrendingUp}   label="Market Prices"  color="var(--color-retail)"    onClick={() => navigate('/app/market')} />
        {hasRole('farmer', 'agent', 'admin') && (
          <QuickAction icon={Leaf}       label="Crop Health"    color="var(--positive)"        onClick={() => navigate('/app/crop-health')} />
        )}
        {!hasRole('agent') && (
          <QuickAction icon={ShoppingBag} label="Input Suppliers" color="var(--color-producer)"  onClick={() => navigate('/app/inputs')} />
        )}
        <QuickAction icon={MessageCircle} label="AI Advisory"   color="var(--accent)"          onClick={() => navigate('/app/advisory')} />
        {hasRole('farmer', 'trader', 'admin') && (
          <QuickAction icon={DollarSign} label="Financial"      color="var(--color-wholesale)" onClick={() => navigate('/app/financial')} />
        )}
      </div>

      {/* My Farms */}
      {hasRole('farmer', 'agent', 'admin') && (
        <>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
            <div className="section-title" style={{ marginBottom: 0 }}>My Farms</div>
            <button className="btn-secondary" onClick={() => navigate('/app/profile')}>Manage</button>
          </div>
          {loadingFarms ? (
            <div className="loading-state">Loading farms…</div>
          ) : farms.length === 0 ? (
            <div className="card empty-state">
              <div className="empty-state-icon"><Leaf size={32} style={{ color: 'var(--text-muted)' }} /></div>
              <div className="empty-state-text">No farms registered yet.</div>
              <button className="btn-primary" style={{ width: 'auto', marginTop: 12 }} onClick={() => navigate('/app/profile')}>Add your first farm</button>
            </div>
          ) : (
            <div className="grid-3" style={{ marginBottom: 28 }}>
              {farms.map(f => (
                <FarmCard key={f.id} farm={f} onClick={() => navigate('/app/crop-health')} />
              ))}
            </div>
          )}
        </>
      )}

      {/* Platform stats */}
      <div className="section-title">Platform Overview</div>
      <div className="grid-4">
        <div className="stat-card">
          <div className="stat-label">Price Records</div>
          <div className="stat-value">445K</div>
          <div className="stat-sub">observations since 2019</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Markets</div>
          <div className="stat-value">309</div>
          <div className="stat-sub">across 6 regions</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Crops Tracked</div>
          <div className="stat-value">19</div>
          <div className="stat-sub">varieties monitored</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Data Range</div>
          <div className="stat-value">7yr</div>
          <div className="stat-sub">2019 – 2026</div>
        </div>
      </div>
    </div>
  )
}
