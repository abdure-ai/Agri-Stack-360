import { useState, useEffect, useCallback, useRef } from 'react'
import { api } from '../api/client'
import { formatFullDate } from '../utils/formatters'
import { RefreshCw, Square, Play, RotateCcw, Clock, CalendarDays, Database, AlertTriangle } from 'lucide-react'

const POLL_RUNNING_MS = 3000
const POLL_IDLE_MS = 30000

const WEEKDAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']

const STATUS = {
  running:     { label: 'Running',              cls: 'badge-role' },
  success:     { label: 'Completed',            cls: 'badge-healthy' },
  partial:     { label: 'Completed with gaps',  cls: 'badge-warning' },
  failed:      { label: 'Failed',               cls: 'badge-critical' },
  cancelled:   { label: 'Stopped',              cls: 'badge-low' },
  interrupted: { label: 'Interrupted',          cls: 'badge-warning' },
}

const SCOPE_LABEL = { active: 'Quick', all: 'Full' }

const RETRAIN = {
  running:   { label: 'Updating',   cls: 'badge-role' },
  success:   { label: 'Updated',    cls: 'badge-healthy' },
  skipped:   { label: 'Not needed', cls: 'badge-low' },
  failed:    { label: 'Failed',     cls: 'badge-critical' },
  cancelled: { label: 'Stopped',    cls: 'badge-warning' },
}

const RESUMABLE = ['cancelled', 'interrupted', 'failed']

// ── Formatting helpers ──────────────────────────────────────────────────────

const num = n => (n ?? 0).toLocaleString()

function formatDateTime(iso) {
  if (!iso) return '—'
  return new Date(iso).toLocaleString('en-GB', {
    day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit',
  })
}

function formatDuration(seconds) {
  if (seconds == null) return '—'
  const s = Math.max(0, Math.round(seconds))
  if (s < 60) return `${s}s`
  const m = Math.round(s / 60)
  if (m < 60) return `${m} min`
  return `${Math.floor(m / 60)} h ${m % 60} min`
}

function runDuration(run) {
  if (!run.finished_at) return null
  return (new Date(run.finished_at) - new Date(run.started_at)) / 1000
}

function daysSince(dateStr) {
  if (!dateStr) return null
  const ms = Date.now() - new Date(dateStr + 'T00:00:00').getTime()
  return Math.floor(ms / 86400000)
}

function StatusBadge({ status }) {
  const s = STATUS[status] || { label: status, cls: 'badge-role' }
  return <span className={`badge ${s.cls}`}>{s.label}</span>
}

function RetrainBadge({ run }) {
  if (!run.retrain) return <span className="sync-hint">Off</span>
  const s = RETRAIN[run.retrain_status]
  if (!s) return <span className="sync-hint">{run.status === 'running' ? 'Waiting' : '—'}</span>
  return <span className={`badge ${s.cls}`} title={run.retrain_message || undefined}>{s.label}</span>
}

// ── Running sync ────────────────────────────────────────────────────────────

function RunningCard({ progress, liveLog, onStop, stopping }) {
  const pct = progress.pairs_total
    ? Math.min(100, (progress.pairs_done / progress.pairs_total) * 100)
    : 0

  let phaseText = 'Starting…'
  if (progress.phase === 'catalog') phaseText = 'Checking nmis.et for new markets and crops…'
  if (progress.phase === 'prices') phaseText = `Fetching prices — ${num(progress.pairs_done)} of ${num(progress.pairs_total)} market/crop pairs`
  if (progress.phase === 'export') phaseText = 'Writing the CSV export…'
  if (progress.phase === 'retrain') phaseText = 'Prices saved. Updating price forecasts with the new data…'

  return (
    <div className="card">
      <div className="sync-card-head">
        <div className="section-title" style={{ marginBottom: 0 }}>
          <RefreshCw size={16} className="sync-spin" /> Sync in progress
        </div>
        <span className="badge badge-role">{SCOPE_LABEL[progress.scope]} sync</span>
      </div>

      <div className="sync-phase">{phaseText}</div>
      <div className="sync-progress" role="progressbar" aria-valuenow={Math.round(pct)} aria-valuemin={0} aria-valuemax={100}>
        <div className={`sync-progress-bar${progress.phase === 'prices' ? '' : ' indeterminate'}`}
             style={progress.phase === 'prices' ? { width: `${pct}%` } : undefined} />
      </div>
      {progress.current && <div className="sync-current">Now: {progress.current}</div>}

      <div className="sync-metrics">
        <div><span className="sync-metric-value">{num(progress.rows_added)}</span><span className="sync-metric-label">new prices</span></div>
        <div><span className="sync-metric-value" style={progress.pairs_failed ? { color: 'var(--negative)' } : undefined}>{num(progress.pairs_failed)}</span><span className="sync-metric-label">failed</span></div>
        <div><span className="sync-metric-value">{progress.eta_seconds != null ? formatDuration(progress.eta_seconds) : '—'}</span><span className="sync-metric-label">time left</span></div>
        <div><span className="sync-metric-value">{formatDateTime(progress.started_at)}</span><span className="sync-metric-label">started</span></div>
      </div>

      <div className="action-row" style={{ marginTop: 16 }}>
        <button className="btn-secondary sync-btn-danger" onClick={onStop} disabled={stopping || progress.stop_requested}>
          <Square size={14} /> {progress.stop_requested ? 'Stopping…' : 'Stop sync'}
        </button>
        <span className="sync-hint">You can resume a stopped sync later — nothing fetched so far is lost.</span>
      </div>

      {liveLog.length > 0 && (
        <details className="sync-log-details">
          <summary>Live log</summary>
          <pre className="sync-log">{liveLog.slice(-60).join('\n')}</pre>
        </details>
      )}
    </div>
  )
}

// ── Start a sync ────────────────────────────────────────────────────────────

function StartCard({ overview, lastRun, onStart, onResume, busy }) {
  const [scope, setScope] = useState('active')
  const [refreshCatalog, setRefreshCatalog] = useState(false)
  const [exportCsv, setExportCsv] = useState(false)
  const [retrain, setRetrain] = useState(true)

  const pairs = overview?.database?.pairs
  const est = overview?.estimates_minutes
  const resumable = lastRun && RESUMABLE.includes(lastRun.status)

  return (
    <div className="card">
      <div className="section-title">Run a sync now</div>

      {resumable && (
        <div className="sync-notice">
          <AlertTriangle size={16} />
          <div style={{ flex: 1 }}>
            The last sync ({formatDateTime(lastRun.started_at)}) was {STATUS[lastRun.status].label.toLowerCase()} after {num(lastRun.pairs_done)} of {num(lastRun.pairs_total)} pairs.
          </div>
          <button className="btn-secondary" onClick={() => onResume(lastRun.id)} disabled={busy}>
            <RotateCcw size={14} /> Resume
          </button>
        </div>
      )}

      <div className="sync-options" role="radiogroup" aria-label="Sync scope">
        <label className={`sync-option${scope === 'active' ? ' selected' : ''}`}>
          <input type="radio" name="scope" value="active" checked={scope === 'active'} onChange={() => setScope('active')} />
          <div>
            <div className="sync-option-title">Quick sync <span className="sync-option-tag">recommended daily</span></div>
            <div className="sync-option-sub">
              Markets that reported prices in the last {overview?.active_days ?? 90} days
              {pairs && <> · {num(pairs.active)} pairs · {est.active < 1 ? "under a minute" : `about ${formatDuration(est.active * 60)}`}</>}
            </div>
          </div>
        </label>
        <label className={`sync-option${scope === 'all' ? ' selected' : ''}`}>
          <input type="radio" name="scope" value="all" checked={scope === 'all'} onChange={() => setScope('all')} />
          <div>
            <div className="sync-option-title">Full sync</div>
            <div className="sync-option-sub">
              Every market and crop, including ones that stopped reporting
              {pairs && <> · {num(pairs.all)} pairs · {est.all < 1 ? "under a minute" : `about ${formatDuration(est.all * 60)}`}</>}
            </div>
          </div>
        </label>
      </div>

      <label className="sync-check">
        <input type="checkbox" checked={refreshCatalog} onChange={e => setRefreshCatalog(e.target.checked)} />
        Re-check every market's crop list (finds newly traded crops, adds ~15 min)
      </label>
      <label className="sync-check">
        <input type="checkbox" checked={exportCsv} onChange={e => setExportCsv(e.target.checked)} />
        Update the CSV export when done
      </label>
      <label className="sync-check">
        <input type="checkbox" checked={retrain} onChange={e => setRetrain(e.target.checked)} />
        Update price forecasts when done (skipped if no new prices arrive)
      </label>

      <button className="btn-primary sync-start-btn" disabled={busy}
              onClick={() => onStart({ scope, refresh_catalog: refreshCatalog, export_csv: exportCsv, retrain })}>
        <Play size={14} /> Start {scope === 'active' ? 'quick' : 'full'} sync
      </button>
    </div>
  )
}

// ── Schedule ────────────────────────────────────────────────────────────────

const SCHEDULE_FIELDS = ['enabled', 'time', 'full_sync_weekday', 'refresh_catalog_on_full', 'export_csv', 'retrain_after_sync', 'rate']

function ScheduleCard({ schedule, onSave }) {
  const [form, setForm] = useState(schedule)
  const [saving, setSaving] = useState(false)
  const [message, setMessage] = useState(null)

  // Status polling hands us a new object every few seconds; only reset the
  // form when the saved values actually change, so edits in progress survive.
  const savedKey = JSON.stringify(SCHEDULE_FIELDS.map(k => schedule[k]))
  useEffect(() => { setForm(schedule) }, [savedKey])  // eslint-disable-line react-hooks/exhaustive-deps

  const set = (key, value) => { setForm(f => ({ ...f, [key]: value })); setMessage(null) }

  const dirty = SCHEDULE_FIELDS.some(k =>
    k === 'rate' ? Number(form.rate) !== schedule.rate : form[k] !== schedule[k])

  async function save() {
    setSaving(true)
    setMessage(null)
    try {
      await onSave({
        enabled: form.enabled,
        time: form.time,
        full_sync_weekday: form.full_sync_weekday,
        refresh_catalog_on_full: form.refresh_catalog_on_full,
        export_csv: form.export_csv,
        retrain_after_sync: form.retrain_after_sync,
        rate: Number(form.rate),
      })
      setMessage({ ok: true, text: 'Schedule saved.' })
      setForm(f => ({ ...f, rate: Number(f.rate) }))
    } catch (e) {
      setMessage({ ok: false, text: e.message })
    } finally {
      setSaving(false)
    }
  }

  const next = schedule.next_run
  const nextAt = next && new Date(next.at)
  const dueNow = nextAt && nextAt - Date.now() < 60000

  return (
    <div className="card">
      <div className="section-title"><CalendarDays size={16} /> Automatic daily sync</div>

      <label className="sync-switch">
        <input type="checkbox" checked={form.enabled} onChange={e => set('enabled', e.target.checked)} />
        <span className="sync-switch-track"><span className="sync-switch-thumb" /></span>
        <span>{form.enabled ? 'On' : 'Off'}</span>
      </label>

      <div className="sync-next">
        <Clock size={14} />
        {!schedule.enabled && 'Automatic sync is off. Turn it on and save to sync every day.'}
        {schedule.enabled && next && (dueNow
          ? `Next: starting within a minute (${SCOPE_LABEL[next.scope].toLowerCase()} sync)`
          : `Next: ${nextAt.toLocaleString('en-GB', { weekday: 'short', day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })} — ${SCOPE_LABEL[next.scope].toLowerCase()} sync`)}
      </div>

      <div className="form-group">
        <label className="form-label" htmlFor="sync-time">Daily at (server time)</label>
        <input id="sync-time" type="time" className="form-input" value={form.time}
               onChange={e => set('time', e.target.value)} />
      </div>

      <div className="form-group">
        <label className="form-label" htmlFor="sync-full-day">Full sync once a week on</label>
        <select id="sync-full-day" className="form-select"
                value={form.full_sync_weekday ?? ''}
                onChange={e => set('full_sync_weekday', e.target.value === '' ? null : Number(e.target.value))}>
          <option value="">Never — quick sync every day</option>
          {WEEKDAYS.map((d, i) => <option key={d} value={i}>{d}</option>)}
        </select>
        <div className="sync-hint" style={{ marginTop: 6 }}>Other days run a quick sync.</div>
      </div>

      <label className="sync-check">
        <input type="checkbox" checked={form.refresh_catalog_on_full}
               onChange={e => set('refresh_catalog_on_full', e.target.checked)} />
        Re-check crop lists during the weekly full sync
      </label>
      <label className="sync-check">
        <input type="checkbox" checked={form.export_csv} onChange={e => set('export_csv', e.target.checked)} />
        Update the CSV export after each sync
      </label>
      <label className="sync-check">
        <input type="checkbox" checked={form.retrain_after_sync}
               onChange={e => set('retrain_after_sync', e.target.checked)} />
        Update price forecasts after each sync
      </label>

      <details className="sync-log-details" style={{ marginTop: 4 }}>
        <summary>Advanced</summary>
        <div className="form-group" style={{ marginTop: 10 }}>
          <label className="form-label" htmlFor="sync-rate">Seconds between requests to nmis.et</label>
          <input id="sync-rate" type="number" min="0.3" max="10" step="0.1" className="form-input"
                 value={form.rate} onChange={e => set('rate', e.target.value)} />
          <div className="sync-hint" style={{ marginTop: 6 }}>Keep at 1.0 or higher to be polite to the NMIS server.</div>
        </div>
      </details>

      {message && <div className={message.ok ? 'sync-ok' : 'form-error'} style={{ marginTop: 12 }}>{message.text}</div>}

      <button className="btn-primary" style={{ marginTop: 12 }} disabled={!dirty || saving} onClick={save}>
        {saving ? 'Saving…' : 'Save schedule'}
      </button>
    </div>
  )
}

// ── History ─────────────────────────────────────────────────────────────────

function RunDetail({ runId, onResume, busy }) {
  const [detail, setDetail] = useState(null)
  const [log, setLog] = useState([])
  const [error, setError] = useState('')

  useEffect(() => {
    setDetail(null)
    setError('')
    Promise.all([api.syncRun(runId), api.syncRunLog(runId, 300)])
      .then(([d, l]) => { setDetail(d); setLog(l.lines) })
      .catch(e => setError(e.message))
  }, [runId])

  if (error) return <div className="form-error">{error}</div>
  if (!detail) return <div className="loading-state" style={{ padding: 24 }}>Loading run #{runId}…</div>

  return (
    <div className="sync-detail">
      <div className="sync-card-head">
        <div className="section-title" style={{ marginBottom: 0 }}>Sync #{detail.id}</div>
        <StatusBadge status={detail.status} />
      </div>
      <div className="sync-detail-grid">
        <div><span>Started</span>{formatDateTime(detail.started_at)}</div>
        <div><span>Finished</span>{formatDateTime(detail.finished_at)}</div>
        <div><span>Started by</span>{detail.trigger === 'schedule' ? 'Schedule' : detail.triggered_by}</div>
        <div><span>Pairs checked</span>{num(detail.pairs_done)} / {num(detail.pairs_total)}</div>
        <div><span>New prices</span>{num(detail.rows_added)}</div>
        <div><span>Latest price date</span>{formatFullDate(detail.latest_date_before)} → {formatFullDate(detail.latest_date_after)}</div>
        {detail.resumed_from && <div><span>Resumed from</span>#{detail.resumed_from}</div>}
        <div><span>Forecasts</span><RetrainBadge run={detail} /></div>
      </div>
      {detail.retrain_message && (
        <div className={detail.retrain_status === 'failed' ? 'form-error' : 'sync-hint'} style={{ marginTop: 10 }}>
          {detail.retrain_message}
        </div>
      )}

      {detail.error && <div className="form-error" style={{ marginTop: 12 }}>{detail.error}</div>}

      {RESUMABLE.includes(detail.status) && (
        <button className="btn-secondary" style={{ marginTop: 12 }} onClick={() => onResume(detail.id)} disabled={busy}>
          <RotateCcw size={14} /> Resume this sync
        </button>
      )}

      {detail.failed_pairs.length > 0 && (
        <>
          <div className="sync-subtitle">Pairs that failed ({detail.failed_pairs.length}) — they will be retried on the next sync</div>
          <ul className="sync-failed-list">
            {detail.failed_pairs.map(p => (
              <li key={`${p.market_id}-${p.variety_id}`}>
                {p.market_name} ({p.region}) · {p.variety_name}
              </li>
            ))}
          </ul>
        </>
      )}

      <div className="sync-subtitle">Log</div>
      <pre className="sync-log">{log.length ? log.join('\n') : 'No log for this run.'}</pre>
    </div>
  )
}

function HistoryCard({ runs, onResume, busy }) {
  const [selected, setSelected] = useState(null)

  if (!runs.length) {
    return (
      <div className="card">
        <div className="section-title">Sync history</div>
        <div className="empty-state"><div className="empty-state-text">No syncs yet. Start one above.</div></div>
      </div>
    )
  }

  return (
    <div className="card">
      <div className="section-title">Sync history</div>
      <div style={{ overflowX: 'auto' }}>
        <table className="sync-table">
          <thead>
            <tr>
              {['Started', 'Type', 'Started by', 'Status', 'Duration', 'New prices', 'Failed', 'Forecasts'].map(h => <th key={h}>{h}</th>)}
            </tr>
          </thead>
          <tbody>
            {runs.map(r => (
              <tr key={r.id} className={selected === r.id ? 'selected' : ''}
                  onClick={() => setSelected(s => s === r.id ? null : r.id)}
                  tabIndex={0} onKeyDown={e => e.key === 'Enter' && setSelected(s => s === r.id ? null : r.id)}>
                <td>{formatDateTime(r.started_at)}</td>
                <td>{SCOPE_LABEL[r.scope]}{r.resumed_from ? ' (resumed)' : ''}</td>
                <td>{r.trigger === 'schedule' ? 'Schedule' : r.triggered_by}</td>
                <td><StatusBadge status={r.status} /></td>
                <td>{r.status === 'running' ? '—' : formatDuration(runDuration(r))}</td>
                <td>{num(r.rows_added)}</td>
                <td style={r.pairs_failed ? { color: 'var(--negative)' } : undefined}>{num(r.pairs_failed)}</td>
                <td><RetrainBadge run={r} /></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {selected && <RunDetail runId={selected} onResume={onResume} busy={busy} />}
    </div>
  )
}

// ── Screen ──────────────────────────────────────────────────────────────────

export default function DataSyncScreen() {
  const [status, setStatus] = useState(null)
  const [overview, setOverview] = useState(null)
  const [runs, setRuns] = useState([])
  const [offline, setOffline] = useState(false)
  const [error, setError] = useState('')
  const [actionBusy, setActionBusy] = useState(false)
  const wasRunning = useRef(false)

  const loadAll = useCallback(async () => {
    const [s, o, r] = await Promise.all([api.syncStatus(), api.syncOverview(), api.syncRuns(20)])
    setStatus(s); setOverview(o); setRuns(r)
    wasRunning.current = !!s.running
  }, [])

  // Initial load
  useEffect(() => {
    loadAll()
      .then(() => setOffline(false))
      .catch(e => (e.status ? setError(e.message) : setOffline(true)))
  }, [loadAll])

  // Polling — fast while a sync runs, slow otherwise
  const running = !!status?.running
  const loaded = status !== null
  useEffect(() => {
    if (!loaded) return
    const id = setInterval(async () => {
      try {
        const s = await api.syncStatus()
        setStatus(s)
        setOffline(false)
        if (wasRunning.current && !s.running) {
          // A run just finished — refresh totals and history
          const [o, r] = await Promise.all([api.syncOverview(), api.syncRuns(20)])
          setOverview(o); setRuns(r)
        }
        wasRunning.current = !!s.running
      } catch (e) {
        if (!e.status) setOffline(true)
      }
    }, running ? POLL_RUNNING_MS : POLL_IDLE_MS)
    return () => clearInterval(id)
  }, [running, loaded])

  async function act(fn) {
    setActionBusy(true)
    setError('')
    try {
      await fn()
      const [s, r] = await Promise.all([api.syncStatus(), api.syncRuns(20)])
      setStatus(s); setRuns(r)
      wasRunning.current = !!s.running
    } catch (e) {
      setError(e.message)
    } finally {
      setActionBusy(false)
    }
  }

  const start  = opts => act(() => api.syncStart(opts))
  const resume = id => act(() => api.syncResume(id))
  const stop   = () => act(() => api.syncStop())

  async function saveSchedule(settings) {
    const schedule = await api.saveSyncSchedule(settings)
    setStatus(s => ({ ...s, schedule }))
  }

  const header = (
    <div className="screen-header">
      <div className="screen-title">Data Sync</div>
      <div className="screen-subtitle">Keep market prices up to date from nmis.et</div>
    </div>
  )

  if (offline) {
    return (
      <div className="sync-screen">
        {header}
        <div className="card sync-offline">
          <Database size={28} />
          <div className="section-title" style={{ marginBottom: 6 }}>The sync service is not running</div>
          <div className="sync-hint">Start it from the project folder, then reload this page:</div>
          <pre className="sync-log" style={{ marginTop: 10 }}>uvicorn scraper.api:app --port 8002</pre>
          <button className="btn-secondary" style={{ marginTop: 12 }} onClick={() => window.location.reload()}>
            <RefreshCw size={14} /> Try again
          </button>
        </div>
      </div>
    )
  }

  if (!status || !overview) {
    return error
      ? <div className="sync-screen">{header}<div className="form-error">{error}</div></div>
      : <div className="loading-state">Loading data sync…</div>
  }

  const db = overview.database
  const age = daysSince(db.latest_date)
  const models = overview.models
  const forecastsBehind = models && db.latest_date && models.latest_data_date < db.latest_date

  return (
    <div className="sync-screen">
      {header}

      {error && <div className="form-error">{error}</div>}

      <div className="grid-4" style={{ marginBottom: 20 }}>
        <div className="stat-card">
          <div className="stat-label">Price records</div>
          <div className="stat-value">{num(db.price_rows)}</div>
          <div className="stat-sub">{num(db.markets)} markets · since {formatFullDate(db.earliest_date)}</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Latest price</div>
          <div className="stat-value" style={{ fontSize: 22 }}>{formatFullDate(db.latest_date)}</div>
          <div className="stat-sub" style={age > 14 ? { color: 'var(--supply-under)' } : undefined}>
            {age === 0 ? 'today' : age === 1 ? 'yesterday' : `${age} days ago`}
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Forecasts use data to</div>
          <div className="stat-value" style={{ fontSize: 22 }}>{models ? formatFullDate(models.latest_data_date) : 'Not trained'}</div>
          <div className="stat-sub" style={forecastsBehind ? { color: 'var(--supply-under)' } : undefined}>
            {!models ? 'Run a sync with forecasts on'
              : forecastsBehind ? `Behind the latest prices · trained ${formatDateTime(models.last_retrained_at)}`
              : `Up to date · trained ${formatDateTime(models.last_retrained_at)}`}
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Last sync</div>
          <div className="stat-value" style={{ fontSize: 22 }}>{status.last_run ? formatDateTime(status.last_run.finished_at) : 'Never'}</div>
          <div className="stat-sub">
            {status.last_run
              ? <><StatusBadge status={status.last_run.status} /> {num(status.last_run.rows_added)} new prices</>
              : 'Run your first sync below'}
          </div>
        </div>
      </div>

      <div className="sync-main">
        {status.running
          ? <RunningCard progress={status.running} liveLog={status.live_log} onStop={stop} stopping={actionBusy} />
          : <StartCard overview={overview} lastRun={status.last_run} onStart={start} onResume={resume} busy={actionBusy} />}
        <ScheduleCard schedule={status.schedule} onSave={saveSchedule} />
      </div>

      <HistoryCard runs={runs} onResume={resume} busy={actionBusy || running} />
    </div>
  )
}
