import { useState, useEffect } from 'react'
import { api } from '../api/client'
import { DollarSign, CheckCircle, AlertTriangle } from 'lucide-react'

function ScoreGauge({ score }) {
  const pct = score / 100
  const r = 70
  const circ = 2 * Math.PI * r
  const half = circ / 2
  const dash = pct * half
  const color = score >= 60 ? '#3ea87a' : score >= 40 ? '#e09b3a' : '#e05c5c'

  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', padding: '16px 0' }}>
      <svg width={180} height={100} viewBox="0 0 180 100">
        <path
          d={`M 20 90 A ${r} ${r} 0 0 1 160 90`}
          fill="none" stroke="var(--border-medium)" strokeWidth={14} strokeLinecap="round"
        />
        <path
          d={`M 20 90 A ${r} ${r} 0 0 1 160 90`}
          fill="none" stroke={color} strokeWidth={14} strokeLinecap="round"
          strokeDasharray={`${dash} ${half}`}
          style={{ transition: 'stroke-dasharray 0.8s ease' }}
        />
      </svg>
      <div style={{ fontWeight: 800, fontSize: 36, color, marginTop: -20 }}>{score}</div>
      <div style={{ fontSize: 13, color: 'var(--text-muted)' }}>out of 100</div>
      <div style={{ fontSize: 12, fontWeight: 600, marginTop: 4, color }}>
        {score >= 70 ? 'Excellent' : score >= 55 ? 'Good' : score >= 40 ? 'Fair' : 'Needs Improvement'}
      </div>
    </div>
  )
}

export default function FinancialScreen() {
  const [profile, setProfile] = useState(null)
  const [loans, setLoans] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  useEffect(() => {
    Promise.all([api.creditProfile(), api.loanProducts()])
      .then(([p, l]) => { setProfile(p); setLoans(l) })
      .catch(e => setError('Could not load financial data.'))
      .finally(() => setLoading(false))
  }, [])

  if (loading) return <div className="loading-state">Loading financial profile…</div>
  if (error)   return <div className="form-error">{error}</div>

  return (
    <div>
      <div className="screen-header">
        <div className="screen-title">Financial Intelligence</div>
        <div className="screen-subtitle">Your credit profile and matched loan products</div>
      </div>

      <div className="grid-2" style={{ gap: 20, alignItems: 'start' }}>
        {/* Left: Score + factors */}
        <div>
          <div className="card" style={{ marginBottom: 16 }}>
            <div className="section-title">Credit Score</div>
            <ScoreGauge score={profile.score} />
          </div>

          {profile.positive_factors?.length > 0 && (
            <div className="card" style={{ marginBottom: 12 }}>
              <div className="section-title" style={{ color: '#3ea87a' }}>Positive Factors</div>
              {profile.positive_factors.map((f, i) => (
                <div key={i} style={{ display: 'flex', gap: 10, padding: '8px 0', borderBottom: '1px solid var(--border-subtle)' }}>
                  <CheckCircle size={16} style={{ color: '#3ea87a', flexShrink: 0, marginTop: 1 }} />
                  <div style={{ flex: 1 }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                      <span style={{ fontSize: 13, fontWeight: 600, color: 'var(--text-primary)' }}>{f.label}</span>
                      <span style={{ fontSize: 13, fontWeight: 700, color: '#3ea87a' }}>{f.points}</span>
                    </div>
                    {f.detail && <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>{f.detail}</div>}
                  </div>
                </div>
              ))}
            </div>
          )}

          {profile.risk_factors?.length > 0 && (
            <div className="card">
              <div className="section-title" style={{ color: '#e09b3a' }}>Risk Factors</div>
              {profile.risk_factors.map((f, i) => (
                <div key={i} style={{ display: 'flex', gap: 10, padding: '8px 0', borderBottom: '1px solid var(--border-subtle)' }}>
                  <AlertTriangle size={16} style={{ color: '#e09b3a', flexShrink: 0, marginTop: 1 }} />
                  <div style={{ flex: 1 }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                      <span style={{ fontSize: 13, fontWeight: 600, color: 'var(--text-primary)' }}>{f.label}</span>
                      <span style={{ fontSize: 13, fontWeight: 700, color: '#e09b3a' }}>{f.points}</span>
                    </div>
                    {f.detail && <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>{f.detail}</div>}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Right: AI + Loans */}
        <div>
          {profile.ai_explanation && (
            <div className="ai-card" style={{ marginBottom: 16 }}>
              <div className="ai-label">AI Explanation</div>
              <div className="ai-text">{profile.ai_explanation}</div>
            </div>
          )}

          {loans && (
            <>
              <div className="section-title">Matched Loan Products ({loans.matched?.length || 0})</div>
              {loans.matched?.length === 0 && (
                <div style={{ fontSize: 13, color: 'var(--text-muted)', marginBottom: 16 }}>No loan products match your current credit score and role. Improve your score to unlock products.</div>
              )}
              {loans.matched?.map(lp => (
                <div key={lp.id} className="card" style={{ marginBottom: 12 }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 8 }}>
                    <div>
                      <div style={{ fontWeight: 700, fontSize: 14, color: 'var(--text-primary)' }}>{lp.product_name}</div>
                      <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>{lp.lender}</div>
                    </div>
                    <span className="badge badge-eligible">Eligible</span>
                  </div>
                  <div className="grid-3" style={{ gap: 10, marginBottom: 10 }}>
                    <div>
                      <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>Max Amount</div>
                      <div style={{ fontSize: 14, fontWeight: 700, color: 'var(--text-primary)' }}>{lp.max_amount?.toLocaleString()} ETB</div>
                    </div>
                    <div>
                      <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>Interest Rate</div>
                      <div style={{ fontSize: 14, fontWeight: 700, color: lp.interest_rate === 0 ? '#3ea87a' : 'var(--text-primary)' }}>
                        {lp.interest_rate === 0 ? 'Grant (0%)' : `${lp.interest_rate}% p.a.`}
                      </div>
                    </div>
                    <div>
                      <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>Term</div>
                      <div style={{ fontSize: 14, fontWeight: 700, color: 'var(--text-primary)' }}>{lp.term_months} months</div>
                    </div>
                  </div>
                  {lp.monthly_payment && lp.interest_rate > 0 && (
                    <div style={{ fontSize: 12, color: 'var(--text-secondary)', marginBottom: 10 }}>
                      Est. monthly payment: <strong>{lp.monthly_payment?.toLocaleString()} ETB</strong>
                    </div>
                  )}
                  <button className="btn-secondary" style={{ fontSize: 12 }}>Express Interest</button>
                </div>
              ))}

              {loans.ineligible?.length > 0 && (
                <>
                  <div className="section-title" style={{ marginTop: 20, color: 'var(--text-muted)' }}>Locked Products ({loans.ineligible.length})</div>
                  {loans.ineligible.map(lp => (
                    <div key={lp.id} className="card" style={{ marginBottom: 10, opacity: 0.6 }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                        <div>
                          <div style={{ fontWeight: 600, fontSize: 13, color: 'var(--text-primary)' }}>{lp.product_name}</div>
                          <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>{lp.lender}</div>
                        </div>
                        <span className="badge badge-warning" style={{ fontSize: 10 }}>
                          {lp.match_status === 'ineligible_role' ? 'Role mismatch' : `Score +${lp.score_gap} needed`}
                        </span>
                      </div>
                    </div>
                  ))}
                </>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  )
}
