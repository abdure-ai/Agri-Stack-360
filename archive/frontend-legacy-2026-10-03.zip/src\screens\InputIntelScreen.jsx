import { useState, useEffect } from 'react'
import { useAuth } from '../contexts/AuthContext'
import { api } from '../api/client'
import { ShoppingBag, Phone, Star, MapPin } from 'lucide-react'

const CATEGORIES = ['All', 'Fungicide', 'Fertilizer', 'Seeds', 'Herbicide']
const REGIONS = ['All', 'Oromia', 'Amhara', 'SNNP', 'Sidama', 'Tigray']

function StockBadge({ stock }) {
  const color = stock === 'In Stock' ? '#3ea87a' : stock === 'Low Stock' ? '#e09b3a' : '#e05c5c'
  return <span style={{ fontSize: 10, fontWeight: 600, color, background: `${color}18`, padding: '2px 6px', borderRadius: 99 }}>{stock}</span>
}

export default function InputIntelScreen() {
  const { user } = useAuth()
  const [suppliers, setSuppliers] = useState([])
  const [loading, setLoading] = useState(true)
  const [category, setCategory] = useState('All')
  const [region, setRegion] = useState(user?.region || 'All')
  const [selected, setSelected] = useState([])
  const [comparing, setComparing] = useState(false)
  const [comparison, setComparison] = useState('')
  const [compError, setCompError] = useState('')

  useEffect(() => {
    setLoading(true)
    const params = {}
    if (category !== 'All') params.category = category
    if (region !== 'All') params.region = region
    api.getSuppliers(params)
      .then(setSuppliers)
      .catch(() => setSuppliers([]))
      .finally(() => setLoading(false))
  }, [category, region])

  function toggleSelect(id) {
    setSelected(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id].slice(-5))
  }

  async function handleCompare() {
    if (selected.length < 2) return
    setComparing(true)
    setComparison('')
    setCompError('')
    try {
      const res = await api.compareSuppliers({ supplier_ids: selected, context: category !== 'All' ? `Need ${category}` : null })
      setComparison(res.comparison)
    } catch {
      setCompError('Comparison failed.')
    } finally {
      setComparing(false)
    }
  }

  return (
    <div>
      <div className="screen-header">
        <div className="screen-title">Input Intelligence</div>
        <div className="screen-subtitle">Find nearby agricultural input suppliers with real prices</div>
      </div>

      {/* Filters */}
      <div style={{ display: 'flex', gap: 20, marginBottom: 20, flexWrap: 'wrap' }}>
        <div>
          <div style={{ fontSize: 11, color: 'var(--text-muted)', marginBottom: 6, fontWeight: 600, textTransform: 'uppercase' }}>Category</div>
          <div style={{ display: 'flex', gap: 6 }}>
            {CATEGORIES.map(c => (
              <button key={c} className={`chip-filter${category === c ? ' active' : ''}`} onClick={() => setCategory(c)}>{c}</button>
            ))}
          </div>
        </div>
        <div>
          <div style={{ fontSize: 11, color: 'var(--text-muted)', marginBottom: 6, fontWeight: 600, textTransform: 'uppercase' }}>Region</div>
          <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
            {REGIONS.map(r => (
              <button key={r} className={`chip-filter${region === r ? ' active' : ''}`} onClick={() => setRegion(r)}>{r}</button>
            ))}
          </div>
        </div>
      </div>

      {/* Compare bar */}
      {selected.length >= 2 && (
        <div style={{ background: 'var(--accent-dim)', border: '1px solid var(--accent)', borderRadius: 'var(--radius-md)', padding: '10px 16px', marginBottom: 16, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div style={{ fontSize: 13, color: 'var(--accent)', fontWeight: 500 }}>{selected.length} suppliers selected</div>
          <button className="btn-secondary" onClick={handleCompare} disabled={comparing}>
            {comparing ? 'Comparing…' : 'Compare with AI'}
          </button>
        </div>
      )}

      {/* AI comparison result */}
      {comparison && (
        <div className="ai-card" style={{ marginBottom: 16 }}>
          <div className="ai-label">AI Comparison</div>
          <div className="ai-text">{comparison}</div>
        </div>
      )}
      {compError && <div className="form-error" style={{ marginBottom: 12 }}>{compError}</div>}

      {/* Supplier list */}
      {loading ? (
        <div className="loading-state">Loading suppliers…</div>
      ) : suppliers.length === 0 ? (
        <div className="card empty-state">
          <div className="empty-state-icon"><ShoppingBag size={28} style={{ color: 'var(--text-muted)' }} /></div>
          <div className="empty-state-text">No suppliers found for this filter combination.</div>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          {suppliers.map(s => {
            const isSelected = selected.includes(s.id)
            return (
              <div
                key={s.id}
                className="card"
                style={{ cursor: 'pointer', borderColor: isSelected ? 'var(--accent)' : 'var(--border-subtle)' }}
                onClick={() => toggleSelect(s.id)}
              >
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 12 }}>
                  <div>
                    <div style={{ fontWeight: 700, fontSize: 15, color: 'var(--text-primary)', marginBottom: 4 }}>{s.name}</div>
                    <div style={{ display: 'flex', gap: 12, alignItems: 'center', fontSize: 12, color: 'var(--text-muted)' }}>
                      <span style={{ display: 'flex', alignItems: 'center', gap: 3 }}><MapPin size={11} />{s.region}{s.zone ? `, ${s.zone}` : ''}</span>
                      {s.distance_km && <span>{s.distance_km} km away</span>}
                      <span style={{ display: 'flex', alignItems: 'center', gap: 3 }}>
                        <Star size={11} style={{ color: '#e09b3a' }} fill="#e09b3a" />{s.rating}
                      </span>
                    </div>
                  </div>
                  <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                    {isSelected && <span style={{ background: 'var(--accent)', color: 'white', fontSize: 10, fontWeight: 700, padding: '2px 8px', borderRadius: 99 }}>Selected</span>}
                    {s.phone && (
                      <a href={`tel:${s.phone}`} onClick={e => e.stopPropagation()} style={{ color: 'var(--accent)', fontSize: 12, display: 'flex', alignItems: 'center', gap: 4, textDecoration: 'none' }}>
                        <Phone size={12} /> {s.phone}
                      </a>
                    )}
                  </div>
                </div>

                {/* Products */}
                {s.products?.length > 0 && (
                  <div style={{ borderTop: '1px solid var(--border-subtle)', paddingTop: 10 }}>
                    <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.04em', marginBottom: 8 }}>Products</div>
                    <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                      {s.products.map((p, i) => (
                        <div key={i} style={{ background: 'var(--bg-elevated)', borderRadius: 'var(--radius-md)', padding: '8px 12px', minWidth: 140 }}>
                          <div style={{ fontWeight: 600, fontSize: 13, color: 'var(--text-primary)', marginBottom: 2 }}>{p.name}</div>
                          <div style={{ fontSize: 11, color: 'var(--text-muted)', marginBottom: 4 }}>{p.brand} · {p.unit}</div>
                          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                            <span style={{ fontWeight: 700, fontSize: 14, color: 'var(--accent)' }}>{p.price?.toLocaleString()} ETB</span>
                            <StockBadge stock={p.stock} />
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}
