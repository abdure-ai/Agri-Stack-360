// MarketView.jsx — Wraps existing market chart logic under the new router layout
import { useState, useEffect, useCallback } from 'react'
import { api } from '../api/client'
import FilterSidebar from '../components/FilterSidebar'
import SummaryCards from '../components/SummaryCards'
import TimeSeriesView from '../components/views/TimeSeriesView'
import RegionalComparisonView from '../components/views/RegionalComparisonView'
import HeatmapView from '../components/views/HeatmapView'
import SpreadView from '../components/views/SpreadView'
import ForecastView from '../components/views/ForecastView'
import { exportCsv } from '../utils/exportCsv'

const TABS = [
  { id: 'timeseries', label: 'Time Series' },
  { id: 'regional',   label: 'Regional' },
  { id: 'heatmap',    label: 'Heatmap' },
  { id: 'spread',     label: 'Spread' },
  { id: 'forecast',   label: 'Forecast' },
]

const DEFAULT_FILTERS = {
  crop:        'Teff',
  variety:     '',
  region:      '',
  markets:     [],
  price_level: 'retail',
  start_date:  '2024-01-01',
  end_date:    '2026-08-14',
}

export default function MarketView() {
  const [meta,      setMeta]      = useState(null)
  const [filters,   setFilters]   = useState(DEFAULT_FILTERS)
  const [activeTab, setActiveTab] = useState('timeseries')

  const [priceData,    setPriceData]    = useState(null)
  const [summaryData,  setSummaryData]  = useState(null)
  const [regionalData, setRegionalData] = useState(null)
  const [spreadData,   setSpreadData]   = useState(null)

  const [loadingPrice,    setLoadingPrice]    = useState(false)
  const [loadingRegional, setLoadingRegional] = useState(false)
  const [loadingSpread,   setLoadingSpread]   = useState(false)
  const [forecastOnline,  setForecastOnline]  = useState(null)

  useEffect(() => { api.meta().then(setMeta).catch(() => {}) }, [])

  useEffect(() => {
    function check() {
      api.forecastHealth().then(() => setForecastOnline(true)).catch(() => setForecastOnline(false))
    }
    check()
    const id = setInterval(check, 30_000)
    return () => clearInterval(id)
  }, [])

  const buildParams = useCallback((f) => {
    const p = {
      crop: f.crop || undefined, variety: f.variety || undefined,
      region: f.region || undefined, price_level: f.price_level || 'retail',
      start_date: f.start_date || undefined, end_date: f.end_date || undefined,
    }
    if (f.markets?.length > 0) p.market = f.markets.join(',')
    return p
  }, [])

  const fetchAll = useCallback(async (f) => {
    const params = buildParams(f)
    setLoadingPrice(true); setLoadingRegional(true); setLoadingSpread(true)
    const [prices, summary, regional, spread] = await Promise.allSettled([
      api.prices(params), api.summary(params),
      api.regional({ ...params, market: undefined }), api.spread(params),
    ])
    setLoadingPrice(false); setLoadingRegional(false); setLoadingSpread(false)
    if (prices.status   === 'fulfilled') setPriceData(prices.value)
    if (summary.status  === 'fulfilled') setSummaryData(summary.value)
    if (regional.status === 'fulfilled') setRegionalData(regional.value)
    if (spread.status   === 'fulfilled') setSpreadData(spread.value)
  }, [buildParams])

  useEffect(() => { fetchAll(DEFAULT_FILTERS) }, [fetchAll])

  function handleApply(newFilters) {
    setFilters(newFilters)
    fetchAll(newFilters)
  }

  const cropMeta = meta?.crops.find(c => c.name === filters.crop)
  const statusLabel = forecastOnline === null ? 'checking' : forecastOnline ? 'online' : 'offline'

  return (
    <div>
      <div className="screen-header" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <div className="screen-title">Market Intelligence</div>
          <div className="screen-subtitle">Ethiopian agricultural price data — 445K observations</div>
        </div>
        <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
          <div className={`api-status-dot ${statusLabel}`} title={`Forecast AI: ${statusLabel}`}>
            Forecast AI
          </div>
          {priceData?.data?.length > 0 && (
            <button
              className="btn-secondary"
              onClick={() => exportCsv(priceData.data, `nmis_${filters.crop}_${filters.price_level}.csv`)}
            >
              Export CSV
            </button>
          )}
        </div>
      </div>

      {/* Existing market layout */}
      <div style={{ display: 'grid', gridTemplateColumns: '260px 1fr', gap: 16 }}>
        <FilterSidebar meta={meta} filters={filters} onApply={handleApply} />

        <div>
          <SummaryCards summary={summaryData} filters={filters} loading={loadingPrice} />

          <div className="chart-panel" style={{ marginTop: 16 }}>
            <div className="chart-tabs">
              {TABS.map(tab => (
                <button
                  key={tab.id}
                  className={`chart-tab${activeTab === tab.id ? ' active' : ''}${tab.id === 'forecast' ? ' forecast-tab-btn' : ''}`}
                  onClick={() => setActiveTab(tab.id)}
                >
                  {tab.id === 'forecast' && (
                    <span style={{
                      display: 'inline-block', width: 6, height: 6, borderRadius: '50%',
                      background: forecastOnline ? '#3ea87a' : forecastOnline === false ? '#e05c5c' : 'var(--text-muted)',
                      marginRight: 6, verticalAlign: 'middle',
                    }} />
                  )}
                  {tab.label}
                </button>
              ))}
            </div>
            <div className="chart-body">
              {activeTab === 'timeseries' && <TimeSeriesView data={priceData} filters={filters} loading={loadingPrice} cropMeta={cropMeta} />}
              {activeTab === 'regional'   && <RegionalComparisonView data={regionalData} filters={filters} loading={loadingRegional} />}
              {activeTab === 'heatmap'    && <HeatmapView data={priceData} filters={filters} loading={loadingPrice} />}
              {activeTab === 'spread'     && <SpreadView data={spreadData} filters={filters} loading={loadingSpread} />}
              {activeTab === 'forecast'   && <ForecastView filters={filters} regionalData={regionalData} forecastOnline={forecastOnline} />}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
