import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../contexts/AuthContext'
import { api } from '../api/client'
import { Plus, Trash2, Edit2, CheckCircle } from 'lucide-react'

const REGIONS = ['Oromia', 'Amhara', 'SNNP', 'Sidama', 'South West', 'Tigray', 'Afar', 'Somali']
const CROPS = ['Teff', 'Maize', 'Wheat', 'Sorghum', 'Coffee', 'Sesame', 'Chickpea', 'Haricot Bean', 'Barley', 'Potato', 'Tomato', 'Onion', 'Avocado', 'Mango']
const STATUS_OPTIONS = ['healthy', 'warning', 'critical']

export default function ProfileScreen() {
  const { user, saveAuth, token, logout } = useAuth()
  const navigate = useNavigate()

  const [profile, setProfile] = useState({ name: user?.name || '', region: user?.region || '', zone: user?.zone || '', woreda: user?.woreda || '', language: user?.language || 'en' })
  const [profileSaved, setProfileSaved] = useState(false)
  const [profileError, setProfileError] = useState('')
  const [savingProfile, setSavingProfile] = useState(false)

  const [farms, setFarms] = useState([])
  const [showFarmForm, setShowFarmForm] = useState(false)
  const [editingFarm, setEditingFarm] = useState(null)
  const [farmForm, setFarmForm] = useState({ field_name: '', crop_name: 'Teff', variety: '', area_ha: '', planted_date: '', status: 'healthy', notes: '' })
  const [farmError, setFarmError] = useState('')
  const [savingFarm, setSavingFarm] = useState(false)

  useEffect(() => {
    api.getFarms().then(setFarms).catch(() => {})
  }, [])

  async function saveProfile() {
    setSavingProfile(true)
    setProfileError('')
    try {
      const updated = await api.updateProfile(profile)
      saveAuth(token, { ...user, ...updated })
      setProfileSaved(true)
      setTimeout(() => setProfileSaved(false), 3000)
    } catch (e) {
      setProfileError('Failed to save profile.')
    } finally {
      setSavingProfile(false)
    }
  }

  function openAddFarm() {
    setEditingFarm(null)
    setFarmForm({ field_name: '', crop_name: 'Teff', variety: '', area_ha: '', planted_date: '', status: 'healthy', notes: '' })
    setFarmError('')
    setShowFarmForm(true)
  }

  function openEditFarm(farm) {
    setEditingFarm(farm)
    setFarmForm({ field_name: farm.field_name, crop_name: farm.crop_name, variety: farm.variety || '', area_ha: farm.area_ha || '', planted_date: farm.planted_date || '', status: farm.status, notes: farm.notes || '' })
    setFarmError('')
    setShowFarmForm(true)
  }

  async function saveFarm() {
    if (!farmForm.field_name.trim()) { setFarmError('Field name is required.'); return }
    setSavingFarm(true)
    setFarmError('')
    try {
      const payload = { ...farmForm, area_ha: farmForm.area_ha ? parseFloat(farmForm.area_ha) : null }
      if (editingFarm) {
        const updated = await api.updateFarm(editingFarm.id, payload)
        setFarms(prev => prev.map(f => f.id === editingFarm.id ? updated : f))
      } else {
        const added = await api.addFarm(payload)
        setFarms(prev => [...prev, added])
      }
      setShowFarmForm(false)
    } catch (e) {
      setFarmError(e.message)
    } finally {
      setSavingFarm(false)
    }
  }

  async function deleteFarm(id) {
    if (!confirm('Delete this farm and all its health reports?')) return
    await api.deleteFarm(id)
    setFarms(prev => prev.filter(f => f.id !== id))
  }

  return (
    <div>
      <div className="screen-header">
        <div className="screen-title">My Profile</div>
        <div className="screen-subtitle">Manage your account details and registered farms</div>
      </div>

      <div className="grid-2" style={{ gap: 20, alignItems: 'start' }}>
        {/* Profile */}
        <div className="card">
          <div className="section-title">Account Details</div>
          <div style={{ marginBottom: 12, padding: '10px 12px', background: 'var(--bg-elevated)', borderRadius: 'var(--radius-md)', fontSize: 13 }}>
            <span style={{ color: 'var(--text-muted)' }}>Phone: </span><strong>{user?.phone}</strong>
            <span style={{ marginLeft: 12, color: 'var(--text-muted)' }}>Role: </span>
            <span className="badge badge-role" style={{ marginLeft: 4 }}>{user?.role}</span>
          </div>

          {profileError && <div className="form-error">{profileError}</div>}

          {[
            { label: 'Full Name', key: 'name', type: 'text' },
            { label: 'Zone', key: 'zone', type: 'text' },
            { label: 'Woreda', key: 'woreda', type: 'text' },
          ].map(({ label, key, type }) => (
            <div className="form-group" key={key}>
              <label className="form-label">{label}</label>
              <input className="form-input" type={type} value={profile[key]} onChange={e => setProfile(p => ({ ...p, [key]: e.target.value }))} />
            </div>
          ))}

          <div className="form-group">
            <label className="form-label">Region</label>
            <select className="form-select" value={profile.region} onChange={e => setProfile(p => ({ ...p, region: e.target.value }))}>
              <option value="">Select region</option>
              {REGIONS.map(r => <option key={r} value={r}>{r}</option>)}
            </select>
          </div>

          <div className="form-group">
            <label className="form-label">Language</label>
            <select className="form-select" value={profile.language} onChange={e => setProfile(p => ({ ...p, language: e.target.value }))}>
              <option value="en">English</option>
              <option value="am">Amharic (አማርኛ)</option>
            </select>
          </div>

          <div style={{ display: 'flex', gap: 10, marginTop: 4 }}>
            <button className="btn-primary" style={{ flex: 1 }} onClick={saveProfile} disabled={savingProfile}>
              {savingProfile ? 'Saving…' : 'Save Profile'}
            </button>
            {profileSaved && <div style={{ display: 'flex', alignItems: 'center', gap: 6, color: '#3ea87a', fontSize: 13 }}><CheckCircle size={16} /> Saved</div>}
          </div>

          <button className="btn-secondary" style={{ width: '100%', marginTop: 12, color: 'var(--negative)', borderColor: 'var(--negative)' }} onClick={() => { logout(); navigate('/login') }}>
            Sign out
          </button>
        </div>

        {/* Farms */}
        <div>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
            <div className="section-title" style={{ marginBottom: 0 }}>My Farms</div>
            <button className="btn-secondary" onClick={openAddFarm} style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
              <Plus size={14} /> Add farm
            </button>
          </div>

          {showFarmForm && (
            <div className="card" style={{ marginBottom: 16, border: '1px solid var(--accent)' }}>
              <div className="section-title">{editingFarm ? 'Edit Farm' : 'New Farm'}</div>
              {farmError && <div className="form-error">{farmError}</div>}
              {[
                { label: 'Field Name', key: 'field_name', type: 'text', placeholder: 'e.g. Field 1 — Hirna' },
                { label: 'Variety', key: 'variety', type: 'text', placeholder: 'e.g. BH660' },
                { label: 'Area (hectares)', key: 'area_ha', type: 'number', placeholder: 'e.g. 2.5' },
                { label: 'Planting Date', key: 'planted_date', type: 'date' },
              ].map(({ label, key, type, placeholder }) => (
                <div className="form-group" key={key}>
                  <label className="form-label">{label}</label>
                  <input className="form-input" type={type} placeholder={placeholder} value={farmForm[key]} onChange={e => setFarmForm(f => ({ ...f, [key]: e.target.value }))} />
                </div>
              ))}
              <div className="grid-2" style={{ gap: 12 }}>
                <div className="form-group">
                  <label className="form-label">Crop</label>
                  <select className="form-select" value={farmForm.crop_name} onChange={e => setFarmForm(f => ({ ...f, crop_name: e.target.value }))}>
                    {CROPS.map(c => <option key={c} value={c}>{c}</option>)}
                  </select>
                </div>
                <div className="form-group">
                  <label className="form-label">Status</label>
                  <select className="form-select" value={farmForm.status} onChange={e => setFarmForm(f => ({ ...f, status: e.target.value }))}>
                    {STATUS_OPTIONS.map(s => <option key={s} value={s}>{s}</option>)}
                  </select>
                </div>
              </div>
              <div className="form-group">
                <label className="form-label">Notes</label>
                <input className="form-input" placeholder="Any notes about this field" value={farmForm.notes} onChange={e => setFarmForm(f => ({ ...f, notes: e.target.value }))} />
              </div>
              <div style={{ display: 'flex', gap: 8 }}>
                <button className="btn-primary" style={{ flex: 1 }} onClick={saveFarm} disabled={savingFarm}>{savingFarm ? 'Saving…' : 'Save'}</button>
                <button className="btn-secondary" onClick={() => setShowFarmForm(false)}>Cancel</button>
              </div>
            </div>
          )}

          {farms.length === 0 && !showFarmForm && (
            <div className="card empty-state">
              <div className="empty-state-text">No farms yet. Add your first farm to start tracking crop health.</div>
            </div>
          )}

          {farms.map(farm => (
            <div key={farm.id} className="card" style={{ marginBottom: 10 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                <div>
                  <div style={{ fontWeight: 600, fontSize: 14, color: 'var(--text-primary)', marginBottom: 2 }}>{farm.field_name}</div>
                  <div style={{ fontSize: 12, color: 'var(--text-secondary)' }}>{farm.crop_name}{farm.variety ? ` · ${farm.variety}` : ''}{farm.area_ha ? ` · ${farm.area_ha} ha` : ''}</div>
                </div>
                <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
                  <span className={`badge badge-${farm.status}`}>{farm.status}</span>
                  <button onClick={() => openEditFarm(farm)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-muted)' }}><Edit2 size={14} /></button>
                  <button onClick={() => deleteFarm(farm.id)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--negative)' }}><Trash2 size={14} /></button>
                </div>
              </div>
              {farm.notes && <div style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: 6 }}>{farm.notes}</div>}
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
