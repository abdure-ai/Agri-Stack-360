import { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { useAuth } from '../../contexts/AuthContext'
import { useTheme } from '../../contexts/ThemeContext'
import { api } from '../../api/client'
import { Sun, Moon } from 'lucide-react'

export default function LoginScreen() {
  const { saveAuth } = useAuth()
  const { theme, toggleTheme } = useTheme()
  const navigate = useNavigate()

  const [phone, setPhone] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  async function handleSubmit(e) {
    e.preventDefault()
    setError('')
    setLoading(true)
    try {
      const res = await api.login({ phone, password })
      saveAuth(res.access_token, res.user)
      navigate('/app/dashboard')
    } catch (err) {
      setError(err.message.includes('401') || err.message.includes('Invalid')
        ? 'Incorrect phone or password.'
        : 'Connection error. Is the server running?')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="auth-page">
      <button className="theme-toggle-btn" onClick={toggleTheme} style={{ position: 'absolute', top: 16, right: 16 }}>
        {theme === 'dark' ? <Sun size={16} /> : <Moon size={16} />}
      </button>
      <div className="auth-card">
        <div className="auth-logo">
          <div className="app-logo-icon">N</div>
          <div>
            <div className="app-logo-text">NMIS Agri-Platform</div>
            <div className="app-logo-sub">Ethiopia Agricultural Intelligence</div>
          </div>
        </div>
        <div className="auth-title">Sign in</div>
        <div className="auth-subtitle">Enter your phone number and password</div>

        {error && <div className="form-error">{error}</div>}

        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label className="form-label">Phone Number</label>
            <input
              className="form-input"
              type="tel"
              placeholder="e.g. 0911234567"
              value={phone}
              onChange={e => setPhone(e.target.value)}
              required
            />
          </div>
          <div className="form-group">
            <label className="form-label">Password</label>
            <input
              className="form-input"
              type="password"
              placeholder="Your password"
              value={password}
              onChange={e => setPassword(e.target.value)}
              required
            />
          </div>
          <button className="btn-primary" type="submit" disabled={loading}>
            {loading ? 'Signing in…' : 'Sign in'}
          </button>
        </form>

        <div className="auth-switch">
          No account? <Link to="/register">Create one</Link>
        </div>

        <div style={{ marginTop: 24, padding: '12px', background: 'var(--bg-elevated)', borderRadius: 'var(--radius-md)', fontSize: 12, color: 'var(--text-muted)' }}>
          <strong style={{ color: 'var(--text-secondary)' }}>Demo accounts:</strong><br />
          Admin: 0900000001 / admin123<br />
          Farmer: 0911234567 / farmer123<br />
          Agent: 0922345678 / agent123<br />
          Trader: 0933456789 / trader123
        </div>
      </div>
    </div>
  )
}
