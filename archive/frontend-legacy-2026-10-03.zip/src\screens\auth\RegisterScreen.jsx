import { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { useAuth } from '../../contexts/AuthContext'
import { api } from '../../api/client'

const REGIONS = ['Oromia', 'Amhara', 'SNNP', 'Sidama', 'South West', 'Tigray', 'Afar', 'Somali']
const ROLES = [
  { value: 'farmer', label: 'Farmer — manage farms and crop health' },
  { value: 'agent', label: 'Extension Agent — support farmers in your region' },
  { value: 'trader', label: 'Trader — access market and input data' },
]

export default function RegisterScreen() {
  const { saveAuth } = useAuth()
  const navigate = useNavigate()

  const [form, setForm] = useState({ name: '', phone: '', password: '', role: 'farmer', region: '', zone: '' })
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  function set(k) { return e => setForm(f => ({ ...f, [k]: e.target.value })) }

  async function handleSubmit(e) {
    e.preventDefault()
    setError('')
    if (form.password.length < 6) { setError('Password must be at least 6 characters.'); return }
    setLoading(true)
    try {
      const res = await api.register(form)
      saveAuth(res.access_token, res.user)
      navigate('/app/dashboard')
    } catch (err) {
      setError(err.message.includes('409') ? 'Phone number already registered.' : err.message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="auth-page">
      <div className="auth-card">
        <div className="auth-logo">
          <div className="app-logo-icon">N</div>
          <div>
            <div className="app-logo-text">NMIS Agri-Platform</div>
            <div className="app-logo-sub">Create your account</div>
          </div>
        </div>

        {error && <div className="form-error">{error}</div>}

        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label className="form-label">Full Name</label>
            <input className="form-input" placeholder="e.g. Abdurezak Gemechu" value={form.name} onChange={set('name')} required />
          </div>
          <div className="form-group">
            <label className="form-label">Phone Number</label>
            <input className="form-input" type="tel" placeholder="e.g. 0911234567" value={form.phone} onChange={set('phone')} required />
          </div>
          <div className="form-group">
            <label className="form-label">Password</label>
            <input className="form-input" type="password" placeholder="At least 6 characters" value={form.password} onChange={set('password')} required />
          </div>
          <div className="form-group">
            <label className="form-label">I am a…</label>
            <select className="form-select" value={form.role} onChange={set('role')}>
              {ROLES.map(r => <option key={r.value} value={r.value}>{r.label}</option>)}
            </select>
          </div>
          <div className="grid-2" style={{ gap: 12 }}>
            <div className="form-group">
              <label className="form-label">Region</label>
              <select className="form-select" value={form.region} onChange={set('region')}>
                <option value="">Select region</option>
                {REGIONS.map(r => <option key={r} value={r}>{r}</option>)}
              </select>
            </div>
            <div className="form-group">
              <label className="form-label">Zone (optional)</label>
              <input className="form-input" placeholder="e.g. Jimma" value={form.zone} onChange={set('zone')} />
            </div>
          </div>
          <button className="btn-primary" type="submit" disabled={loading}>
            {loading ? 'Creating account…' : 'Create account'}
          </button>
        </form>

        <div className="auth-switch">
          Already have an account? <Link to="/login">Sign in</Link>
        </div>
      </div>
    </div>
  )
}
