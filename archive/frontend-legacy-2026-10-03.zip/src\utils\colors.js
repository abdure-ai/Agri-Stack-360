// utils/colors.js — Color palette for NMIS Dashboard charts

/** Region-to-color mapping (color-blind friendly) */
export const REGION_COLORS = {
  'Oromia':     '#5b9bd5',
  'Amhara':     '#4dbb8a',
  'SNNP':       '#e8975a',
  'Tigray':     '#c07ad5',
  'Sidama':     '#e86b6b',
  'South West': '#5bc4c4',
}

/** Fallback palette for market-level time series (up to 5 markets) */
export const MARKET_COLORS = [
  '#5b9bd5',  // blue
  '#4dbb8a',  // green
  '#e8975a',  // amber
  '#c07ad5',  // purple
  '#e86b6b',  // coral
]

/** Price level brand colors */
export const PRICE_LEVEL_COLORS = {
  retail:    '#5b9bd5',
  wholesale: '#4dbb8a',
  producer:  '#e8975a',
}

/** Get a sequential heatmap color for a normalized value [0, 1] */
export function heatColor(norm) {
  if (norm === null || norm === undefined) return '#1e2535'
  // Low = cool blue-grey, High = warm amber
  const stops = [
    [0.0,  [42,  75,  115]],
    [0.33, [45,  120, 160]],
    [0.66, [180, 130, 60]],
    [1.0,  [210, 90,  50]],
  ]
  let lo = stops[0], hi = stops[stops.length - 1]
  for (let i = 0; i < stops.length - 1; i++) {
    if (norm >= stops[i][0] && norm <= stops[i + 1][0]) {
      lo = stops[i]; hi = stops[i + 1]; break
    }
  }
  const t = (norm - lo[0]) / (hi[0] - lo[0])
  const r = Math.round(lo[1][0] + t * (hi[1][0] - lo[1][0]))
  const g = Math.round(lo[1][1] + t * (hi[1][1] - lo[1][1]))
  const b = Math.round(lo[1][2] + t * (hi[1][2] - lo[1][2]))
  return `rgb(${r},${g},${b})`
}

/** Normalize a value within a [min, max] range to [0, 1] */
export function normalize(value, min, max) {
  if (min === max) return 0.5
  return Math.max(0, Math.min(1, (value - min) / (max - min)))
}
