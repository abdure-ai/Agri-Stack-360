export function exportCsv(rows, filename = 'export.csv') {
  if (!rows || rows.length === 0) return
  const cols = Object.keys(rows[0])
  const lines = [cols.join(',')]
  for (const row of rows) {
    lines.push(cols.map(c => {
      const v = row[c] ?? ''
      return String(v).includes(',') ? `"${v}"` : v
    }).join(','))
  }
  const blob = new Blob([lines.join('\n')], { type: 'text/csv' })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url; a.download = filename; a.click()
  URL.revokeObjectURL(url)
}
