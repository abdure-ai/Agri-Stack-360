// utils/formatters.js — ETB formatting and date utilities

/** Format a number as Ethiopian Birr with comma separators */
export function formatETB(value, unit = '') {
  if (value === null || value === undefined) return '—'
  const formatted = new Intl.NumberFormat('en-US', {
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(Math.round(value))
  return unit ? `${formatted} ETB/${unit}` : `${formatted} ETB`
}

/** Format a percentage change with sign and color class */
export function formatPct(value) {
  if (value === null || value === undefined) return { text: '—', cls: '' }
  const sign = value > 0 ? '+' : ''
  return {
    text: `${sign}${value.toFixed(1)}%`,
    cls: value > 0 ? 'positive' : value < 0 ? 'negative' : '',
  }
}

/** Format ISO date string as "Jun 2025" */
export function formatMonthYear(dateStr) {
  if (!dateStr) return ''
  const d = new Date(dateStr + 'T00:00:00')
  return d.toLocaleDateString('en-US', { month: 'short', year: 'numeric' })
}

/** Format ISO date string as "11 Aug 2026" */
export function formatFullDate(dateStr) {
  if (!dateStr) return '—'
  const d = new Date(dateStr + 'T00:00:00')
  return d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })
}

/** Format short date for axis labels "Aug '26" */
export function formatAxisDate(dateStr) {
  if (!dateStr) return ''
  const d = new Date(dateStr + 'T00:00:00')
  const month = d.toLocaleDateString('en-US', { month: 'short' })
  const year = String(d.getFullYear()).slice(2)
  return `${month} '${year}`
}

/** Tooltip formatter for Recharts — shows ETB value */
export function tooltipFormatter(value, name) {
  if (value === null || value === undefined) return ['—', name]
  return [`${Number(value).toLocaleString('en-US')} ETB`, name]
}

/** Clamp a date string to a [min, max] range */
export function clampDate(dateStr, min, max) {
  if (!dateStr) return min
  if (dateStr < min) return min
  if (dateStr > max) return max
  return dateStr
}
