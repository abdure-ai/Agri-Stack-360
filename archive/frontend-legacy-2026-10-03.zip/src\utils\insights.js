// utils/insights.js
// Plain-language market analysis for farmers and agricultural traders.
// Language target: simple, short sentences, no technical jargon.

import { formatETB, formatMonthYear } from './formatters'

function avg(arr) { return arr.length ? arr.reduce((a, b) => a + b, 0) / arr.length : 0 }
function stdDev(arr) {
  const m = avg(arr)
  return Math.sqrt(arr.reduce((a, v) => a + (v - m) ** 2, 0) / arr.length)
}
function pctChange(val, base) { return base ? ((val - base) / Math.abs(base)) * 100 : 0 }

// ── Time Series ──────────────────────────────────────────────────────────────

export function analyzeTimeSeries(rawRows, filters, unit) {
  // Aggregate to ONE value per date (average across all reporting markets).
  // rawRows has one row per market per date — we must aggregate first so the
  // statistics match what the chart line actually shows.
  const byDate = {}
  for (const r of (rawRows || [])) {
    if (r.price_avg == null) continue
    if (!byDate[r.date]) byDate[r.date] = []
    byDate[r.date].push(r.price_avg)
  }
  const sorted = Object.entries(byDate)
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([date, prices]) => ({ date, p: avg(prices) }))

  if (sorted.length < 12) return null

  const vals    = sorted.map(r => r.p)
  const n       = vals.length
  const qN      = Math.max(3, Math.floor(n / 4))
  const startA  = avg(vals.slice(0, qN))
  const endA    = avg(vals.slice(-qN))
  const trend   = pctChange(endA, startA)
  const mean    = avg(vals)
  const cv      = (stdDev(vals) / mean) * 100
  const maxP     = Math.max(...vals)
  const minP     = Math.min(...vals)
  const peakDate = sorted[vals.indexOf(maxP)].date
  const current  = vals[n - 1]
  const fromPeak = pctChange(current, maxP)
  const prior8   = vals.slice(-12, -4)
  const recent4  = vals.slice(-4)
  const momentum = prior8.length ? pctChange(avg(recent4), avg(prior8)) : 0

  const crop   = filters?.crop   || 'This crop'
  const region = filters?.region ? ` in ${filters.region}` : ''

  // Simple headline
  let headline
  if (trend > 2)       headline = `${crop} prices${region} have gone UP by ${trend.toFixed(0)}% over this period.`
  else if (trend < -2) headline = `${crop} prices${region} have gone DOWN by ${Math.abs(trend).toFixed(0)}% over this period.`
  else                 headline = `${crop} prices${region} have stayed about the same over this period.`

  const bullets = []

  // Price direction — plain cause
  if (trend > 5) {
    bullets.push(`Prices have been rising. This usually means more people are buying, or there is less crop available in the market.`)
  } else if (trend > 2) {
    bullets.push(`Prices are slowly going up. This is a moderate increase — the market is getting slightly more expensive.`)
  } else if (trend < -5) {
    bullets.push(`Prices have been falling. This usually means more crop is available, or fewer people are buying right now.`)
  } else if (trend < -2) {
    bullets.push(`Prices are slowly going down. There may be more supply coming into the market.`)
  } else {
    bullets.push(`Prices have been steady. The market has not changed much — buyers and sellers are roughly balanced.`)
  }

  // Peak and current
  if (current < maxP * 0.94) {
    bullets.push(
      `The highest price was ${formatETB(maxP, unit)} in ${formatMonthYear(peakDate)}. ` +
      `Today's price (${formatETB(current, unit)}) is ${Math.abs(fromPeak).toFixed(0)}% lower than that high point.`
    )
  } else {
    bullets.push(
      `Prices are near their highest point of ${formatETB(maxP, unit)}, last seen in ${formatMonthYear(peakDate)}. ` +
      `The market is strong right now.`
    )
  }

  // Volatility — plain language
  if (cv > 22) {
    bullets.push(`Prices jump up and down a lot from week to week. It is hard to predict what price you will get. Try selling in small amounts, not all at once.`)
  } else if (cv > 11) {
    bullets.push(`Prices change some from week to week, but not too much. This is normal for most crops.`)
  } else {
    bullets.push(`Prices have been very stable. You can plan your sales with more confidence.`)
  }

  // Recent momentum
  if (momentum > 4 && prior8.length >= 4) {
    bullets.push(`In the last 4 weeks, prices have been going UP quickly. This could be a good time to sell.`)
  } else if (momentum < -4 && prior8.length >= 4) {
    bullets.push(`In the last 4 weeks, prices have been going DOWN. You may want to sell soon before prices fall further.`)
  }

  return { headline, bullets }
}

// ── Regional Comparison ──────────────────────────────────────────────────────

export function analyzeRegional(rawRows, filters, unit) {
  if (!rawRows || rawRows.length < 6) return null

  const sorted   = [...rawRows].sort((a, b) => a.date.localeCompare(b.date))
  const allDates = [...new Set(sorted.map(r => r.date))]
  const recentSet = new Set(allDates.slice(-4))

  const recentMap = {}
  for (const r of sorted) {
    if (!recentSet.has(r.date) || r.price_avg == null) continue
    if (!recentMap[r.region]) recentMap[r.region] = []
    recentMap[r.region].push(r.price_avg)
  }
  const recentAvg = Object.fromEntries(
    Object.entries(recentMap).map(([reg, arr]) => [reg, avg(arr)])
  )

  const regions = Object.keys(recentAvg)
  if (regions.length < 2) return null

  const priceVals = Object.values(recentAvg)
  const maxReg = regions.reduce((a, b) => recentAvg[a] > recentAvg[b] ? a : b)
  const minReg = regions.reduce((a, b) => recentAvg[a] < recentAvg[b] ? a : b)
  const maxP   = recentAvg[maxReg]
  const minP   = recentAvg[minReg]
  const spread = pctChange(maxP, minP)
  const natAvg = avg(priceVals)

  const crop = filters?.crop || 'This crop'

  const headline = spread > 20
    ? `${crop} prices are very different across regions right now. ${maxReg} pays the most, ${minReg} pays the least.`
    : `${crop} prices are similar across most regions. The difference between areas is small.`

  const bullets = []

  // Best and worst region
  bullets.push(
    `If you sell in ${maxReg}, you can get around ${formatETB(maxP, unit)}. ` +
    `In ${minReg}, prices are lower at ${formatETB(minP, unit)}. ` +
    `The difference is ${formatETB(maxP - minP, unit)} per ${unit || 'unit'}.`
  )

  // National average
  bullets.push(
    `The average price across all ${regions.length} regions is ${formatETB(natAvg, unit)}. ` +
    `Use this to compare what you are being offered at your local market.`
  )

  // Convergence / divergence
  if (allDates.length >= 8) {
    const thirdN   = Math.max(2, Math.floor(allDates.length / 3))
    const earlySet = new Set(allDates.slice(0, thirdN))
    const lateSet  = new Set(allDates.slice(-thirdN))
    const earlyMap = {}; const lateMap = {}
    for (const r of sorted) {
      if (r.price_avg == null) continue
      if (earlySet.has(r.date)) { earlyMap[r.region] = earlyMap[r.region] || []; earlyMap[r.region].push(r.price_avg) }
      if (lateSet.has(r.date))  { lateMap[r.region]  = lateMap[r.region]  || []; lateMap[r.region].push(r.price_avg) }
    }
    const earlyVals = Object.values(earlyMap).map(a => avg(a))
    const lateVals  = Object.values(lateMap).map(a => avg(a))
    if (earlyVals.length >= 2 && lateVals.length >= 2) {
      const earlyCV = (stdDev(earlyVals) / avg(earlyVals)) * 100
      const lateCV  = (stdDev(lateVals)  / avg(lateVals))  * 100
      if (Math.abs(lateCV - earlyCV) > 3) {
        if (lateCV < earlyCV) {
          bullets.push(`Prices across regions have become more similar over time. It matters less now which region you sell in.`)
        } else {
          bullets.push(`The gap between regions has grown. Selling in the right region makes a bigger difference to your income than before.`)
        }
      }
    }
  }

  // Transport advice
  if (spread > 30) {
    bullets.push(
      `The price gap between regions is very large (${spread.toFixed(0)}%). ` +
      `If transport costs allow, selling in ${maxReg} instead of ${minReg} could earn you significantly more.`
    )
  } else if (spread < 8) {
    bullets.push(`Prices are very close across all regions. Selling at your nearest market is probably the best choice — there is little to gain by travelling further.`)
  }

  return { headline, bullets }
}

// ── Retail–Producer Spread ───────────────────────────────────────────────────

export function analyzeSpread(rawRows, filters, unit) {
  // Aggregate spread by date (average across all markets per week)
  const byDate = {}
  for (const r of (rawRows || [])) {
    if (r.spread == null || r.spread_pct == null) continue
    if (!byDate[r.date]) byDate[r.date] = { spread: [], spread_pct: [] }
    byDate[r.date].spread.push(r.spread)
    byDate[r.date].spread_pct.push(r.spread_pct)
  }
  const aggregated = Object.entries(byDate)
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([, v]) => ({ spread: avg(v.spread), spread_pct: avg(v.spread_pct) }))

  if (aggregated.length < 6) return null

  const sorted    = aggregated
  const spreads   = sorted.map(r => r.spread)
  const pcts      = sorted.map(r => r.spread_pct)
  const avgSpread = avg(spreads)
  const avgPct    = avg(pcts)
  const n         = sorted.length
  const thirdN    = Math.max(2, Math.floor(n / 3))
  const earlyPct  = avg(pcts.slice(0, thirdN))
  const latePct   = avg(pcts.slice(-thirdN))
  const trend     = earlyPct ? pctChange(latePct, earlyPct) : 0

  const crop = filters?.crop || 'This crop'

  let headline
  if (avgPct > 40) {
    headline = `Shop buyers pay a lot more for ${crop} than what farmers receive. The middlemen keep a large share.`
  } else if (avgPct > 20) {
    headline = `Shop prices for ${crop} are about ${avgPct.toFixed(0)}% higher than what farmers get paid.`
  } else {
    headline = `The gap between farm prices and shop prices for ${crop} is small. Farmers are getting a fair share.`
  }

  const bullets = []

  // Main spread fact
  bullets.push(
    `For every ${unit || 'unit'} of ${crop} sold, the shop price is ${formatETB(avgSpread, unit)} more than what the farmer gets. ` +
    `That is a ${avgPct.toFixed(0)}% difference. Traders, transport, and handling costs take this amount.`
  )

  // Trend
  if (trend > 5) {
    bullets.push(`The gap between farm prices and shop prices has been GROWING. Farmers are getting a smaller share of the final price over time.`)
  } else if (trend < -5) {
    bullets.push(`The gap between farm prices and shop prices has been SHRINKING. Farmers are getting a better share of the final price.`)
  } else {
    bullets.push(`The gap between farm price and shop price has stayed about the same. No big change in how value is shared.`)
  }

  // Action advice
  if (avgPct > 40) {
    bullets.push(
      `The farm-to-market gap is very high (${avgPct.toFixed(0)}%). ` +
      `If possible, try selling directly at a nearby town market instead of to local traders. ` +
      `This can help you earn more.`
    )
  } else if (avgPct < 10) {
    bullets.push(`The farm-to-shop price gap is small. This is good — it means traders are not taking too much from your earnings.`)
  }

  return { headline, bullets }
}

// ── Forecast Recommendation ──────────────────────────────────────────────────

export function buildForecastRecommendation(forecast, currentPrice, unit) {
  if (!forecast?.predictions?.length || currentPrice == null) return null

  const preds       = forecast.predictions
  const lastPred    = preds[preds.length - 1]
  const forecastP   = lastPred.price_median_etb
  const changePct   = pctChange(forecastP, currentPrice)
  const uncertainty = pctChange(lastPred.price_high_etb - lastPred.price_low_etb, forecastP)
  const weeksN      = forecast.weeks_ahead
  const timeStr     = weeksN <= 2 ? `${weeksN} week${weeksN > 1 ? 's' : ''}` : weeksN <= 4 ? 'about 1 month' : weeksN <= 8 ? 'about 2 months' : 'about 3 months'

  let label, color, bg
  if      (changePct > 8)   { label = 'Wait to Sell';   color = '#3ea87a'; bg = 'rgba(62,168,122,0.10)' }
  else if (changePct > 3)   { label = 'Hold for Now';   color = '#3ea6c4'; bg = 'rgba(62,166,196,0.10)' }
  else if (changePct >= -3) { label = 'Sell Now';       color = '#5b9bd5'; bg = 'rgba(91,155,213,0.10)' }
  else if (changePct >= -8) { label = 'Sell Soon';      color = '#e09b3a'; bg = 'rgba(224,155,58,0.10)' }
  else                      { label = 'Sell Urgently';  color = '#e05c5c'; bg = 'rgba(224,92,92,0.10)'  }

  // Simple headline
  let headline
  const absChange = Math.abs(changePct).toFixed(0)
  if (changePct > 3) {
    headline = `Prices for ${forecast.crop} in ${forecast.region} are expected to go UP by about ${absChange}% over the next ${timeStr}. Waiting to sell may earn you more money.`
  } else if (changePct < -3) {
    headline = `Prices for ${forecast.crop} in ${forecast.region} are expected to go DOWN by about ${absChange}% over the next ${timeStr}. Selling sooner is safer.`
  } else {
    headline = `Prices for ${forecast.crop} in ${forecast.region} are expected to stay about the same over the next ${timeStr}. No big change is forecast.`
  }

  const changeColor = changePct > 1 ? '#3ea87a' : changePct < -1 ? '#e05c5c' : 'var(--text-secondary)'

  const bullets = []

  // Main advice — very direct
  if (label === 'Wait to Sell' || label === 'Hold for Now') {
    bullets.push(
      `Prices are going up. If you can wait ${timeStr} before selling, you could earn about ${absChange}% MORE than today's price. ` +
      `Only wait if you can safely store your crop.`
    )
  } else if (label === 'Sell Now') {
    bullets.push(
      `Prices are not expected to change much. There is no strong reason to wait. ` +
      `Selling now means you get today's fair price without any risk.`
    )
  } else {
    bullets.push(
      `Prices are going down. The longer you wait, the less you may earn. ` +
      `Try to sell your crop as soon as possible.`
    )
  }

  // Uncertainty — simple
  if (uncertainty > 30) {
    bullets.push(
      `This forecast is not certain. Prices could go higher or lower than expected. ` +
      `A safe plan is to sell some now and some later — do not sell everything at once.`
    )
  } else if (uncertainty > 15) {
    bullets.push(
      `There is some uncertainty in this forecast. The direction is likely correct, but the exact price may be different. ` +
      `Watch the market each week.`
    )
  } else {
    bullets.push(`This forecast is fairly reliable. The price direction is based on strong market data.`)
  }

  // Data confidence — plain
  if (forecast.confidence === 'high') {
    bullets.push(`This forecast uses ${forecast.data_history_weeks} weeks of past market data. That is a lot of history, so the prediction is trustworthy.`)
  } else if (forecast.confidence === 'medium') {
    bullets.push(`This forecast is based on ${forecast.data_history_weeks} weeks of past data. It is a reasonable guide but not perfect.`)
  } else if (forecast.confidence === 'low') {
    bullets.push(`We only have ${forecast.data_history_weeks} weeks of past data for this crop and region. Use this as a rough guide and ask your local market agent for more information.`)
  } else {
    bullets.push(`We have very little past data for this crop (${forecast.data_history_weeks} weeks). This forecast is a rough estimate only. Talk to a local trader before making a big decision.`)
  }

  // Production decision
  if (changePct > 3) {
    bullets.push(
      `Growing more ${forecast.crop} for the next season looks like a good idea. ` +
      `Prices are expected to be higher, so your harvest should earn more.`
    )
  } else if (changePct < -3) {
    bullets.push(
      `Be careful about growing a lot of ${forecast.crop} right now. ` +
      `Prices may be lower when your next harvest is ready. ` +
      `Talk to buyers or cooperatives before planting more.`
    )
  } else {
    bullets.push(
      `Growing ${forecast.crop} for the next season is a safe choice. ` +
      `Prices are stable, so your income should be predictable.`
    )
  }

  return { label, color, bg, headline, bullets, changePct, changeColor, currentPrice, forecastPrice: forecastP, uncertainty }
}
